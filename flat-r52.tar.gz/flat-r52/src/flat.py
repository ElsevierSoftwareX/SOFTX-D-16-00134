# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'flat-guiq.ui'
#
# Created: Mon Feb 22 02:00:34 2016
#      by: PyQt4 UI code generator 4.9.3
#
# WARNING! All changes made in this file will be lost!


from PyQt4 import QtCore, QtGui
from PyQt4.QtGui import *
from PyQt4.QtCore import *
import subprocess
import os
import sys
import re
from flat_proxy import *
from util import *
import gabbs.maps
from qgis.core import *
from qgis.gui import *
from PyQt4.QtGui import *
from gabbs.MapUtils import iface
import traceback
import urllib2
from lxml import etree as ET
import time
import pickle
import shutil
import math
import gdal
from gdalconst import *
import itertools

from maptool import *

FLAT_DIR = os.path.expanduser('~/.flat')

running_flat = False

try:
	_fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
	_fromUtf8 = lambda s: s

class Ui_TabWidget():
	def setupUi(self, TabWidget):
		TabWidget.setObjectName(_fromUtf8("TabWidget"))
		#TabWidget.resize(679, 489)
		#zsd
		TabWidget.resize(930, 700)
		self.tab1 = QtGui.QWidget()
		self.tab1.setObjectName(_fromUtf8("tab1"))
		self.layoutWidget = QtGui.QWidget(self.tab1)
		self.layoutWidget.setGeometry(QtCore.QRect(0, 0, 2, 2))
		self.layoutWidget.setObjectName(_fromUtf8("layoutWidget"))
		self.verticalLayout_3 = QtGui.QVBoxLayout(self.layoutWidget)
		self.verticalLayout_3.setMargin(0)
		self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
		self.layoutWidget1 = QtGui.QWidget(self.tab1)
		self.layoutWidget1.setGeometry(QtCore.QRect(0, 0, 2, 2))
		self.layoutWidget1.setObjectName(_fromUtf8("layoutWidget1"))
		self.verticalLayout_4 = QtGui.QVBoxLayout(self.layoutWidget1)
		self.verticalLayout_4.setMargin(0)
		self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
		self.layoutWidget2 = QtGui.QWidget(self.tab1)
		#self.layoutWidget2.setGeometry(QtCore.QRect(10, 10, 661, 431))
		#zsd
		self.layoutWidget2.setGeometry(QtCore.QRect(10, 10, 912, 650))
		self.layoutWidget2.setObjectName(_fromUtf8("layoutWidget2"))
		self.verticalLayout_6 = QtGui.QVBoxLayout(self.layoutWidget2)
		self.verticalLayout_6.setMargin(0)
		self.verticalLayout_6.setObjectName(_fromUtf8("verticalLayout_6"))
		self.horizontalLayout_8 = QtGui.QHBoxLayout()
		self.horizontalLayout_8.setObjectName(_fromUtf8("horizontalLayout_8"))
		self.groupBox = QtGui.QGroupBox(self.layoutWidget2)
		self.groupBox.setAutoFillBackground(False)
		self.groupBox.setFlat(False)
		self.groupBox.setCheckable(False)
		self.groupBox.setObjectName(_fromUtf8("groupBox"))
		self.verticalLayout_2 = QtGui.QVBoxLayout(self.groupBox)
		self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
		self.horizontalLayout = QtGui.QHBoxLayout()
		self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
		self.label = QtGui.QLabel(self.groupBox)
		self.label.setObjectName(_fromUtf8("label"))
		self.horizontalLayout.addWidget(self.label)
		self.lineEdit_ModelName = QtGui.QLineEdit(self.groupBox)
		self.lineEdit_ModelName.setObjectName(_fromUtf8("lineEdit_ModelName"))
		self.horizontalLayout.addWidget(self.lineEdit_ModelName)
		self.verticalLayout_2.addLayout(self.horizontalLayout)
		self.horizontalLayout_2 = QtGui.QHBoxLayout()
		self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
		self.label_2 = QtGui.QLabel(self.groupBox)
		self.label_2.setObjectName(_fromUtf8("label_2"))
		self.horizontalLayout_2.addWidget(self.label_2)
		self.comboBox_dataset = QtGui.QComboBox(self.groupBox)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.comboBox_dataset.sizePolicy().hasHeightForWidth())
		self.comboBox_dataset.setSizePolicy(sizePolicy)
		self.comboBox_dataset.setObjectName(_fromUtf8("comboBox_dataset"))
		self.horizontalLayout_2.addWidget(self.comboBox_dataset)
		self.verticalLayout_2.addLayout(self.horizontalLayout_2)

		self.horizontalLayout_proj = QtGui.QHBoxLayout() # projected dataset selection
		self.horizontalLayout_proj.setObjectName(_fromUtf8("horizontalLayout_2"))
		self.label_proj = QtGui.QLabel(self.groupBox)
		self.label_proj.setObjectName(_fromUtf8("label_proj"))
		self.horizontalLayout_proj.addWidget(self.label_proj)
		self.comboBox_projdataset = QtGui.QComboBox(self.groupBox)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.comboBox_projdataset.sizePolicy().hasHeightForWidth())
		self.comboBox_projdataset.setSizePolicy(sizePolicy)
		self.comboBox_projdataset.setObjectName(_fromUtf8("comboBox_projdataset"))
		self.horizontalLayout_proj.addWidget(self.comboBox_projdataset)
		self.verticalLayout_2.addLayout(self.horizontalLayout_proj)

		self.horizontalLayout_3 = QtGui.QHBoxLayout()
		self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
		self.label_3 = QtGui.QLabel(self.groupBox)
		self.label_3.setObjectName(_fromUtf8("label_3"))
		self.horizontalLayout_3.addWidget(self.label_3)
		self.comboBox_GridSize = QtGui.QComboBox(self.groupBox)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.comboBox_GridSize.sizePolicy().hasHeightForWidth())
		self.comboBox_GridSize.setSizePolicy(sizePolicy)
		self.comboBox_GridSize.setObjectName(_fromUtf8("comboBox_GridSize"))
		self.horizontalLayout_3.addWidget(self.comboBox_GridSize)
		self.verticalLayout_2.addLayout(self.horizontalLayout_3)
		self.horizontalLayout_7 = QtGui.QHBoxLayout()
		self.horizontalLayout_7.setObjectName(_fromUtf8("horizontalLayout_7"))
		self.label_6 = QtGui.QLabel(self.groupBox)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Preferred)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.label_6.sizePolicy().hasHeightForWidth())
		self.label_6.setSizePolicy(sizePolicy)
		self.label_6.setObjectName(_fromUtf8("label_6"))
		self.horizontalLayout_7.addWidget(self.label_6)
		self.verticalLayout = QtGui.QVBoxLayout()
		self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
		self.horizontalLayout_4 = QtGui.QHBoxLayout()
		self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
		self.label_4 = QtGui.QLabel(self.groupBox)
		self.label_4.setFrameShape(QtGui.QFrame.Box)
		self.label_4.setObjectName(_fromUtf8("label_4"))
		self.horizontalLayout_4.addWidget(self.label_4)
		self.comboBox_NumDepVars = QtGui.QComboBox(self.groupBox)
		self.comboBox_NumDepVars.setObjectName(_fromUtf8("comboBox_NumDepVars"))
		self.horizontalLayout_4.addWidget(self.comboBox_NumDepVars)
		self.verticalLayout.addLayout(self.horizontalLayout_4)
		self.horizontalLayout_5 = QtGui.QHBoxLayout()
		self.horizontalLayout_5.setObjectName(_fromUtf8("horizontalLayout_5"))
		self.label_5 = QtGui.QLabel(self.groupBox)
		self.label_5.setFrameShape(QtGui.QFrame.Box)
		self.label_5.setObjectName(_fromUtf8("label_5"))
		self.horizontalLayout_5.addWidget(self.label_5)
		self.comboBox_NumNDepVars = QtGui.QComboBox(self.groupBox)
		self.comboBox_NumNDepVars.setObjectName(_fromUtf8("comboBox_NumNDepVars"))
		self.horizontalLayout_5.addWidget(self.comboBox_NumNDepVars)
		self.verticalLayout.addLayout(self.horizontalLayout_5)
		self.horizontalLayout_7.addLayout(self.verticalLayout)
		self.verticalLayout_2.addLayout(self.horizontalLayout_7)
		self.horizontalLayout_6 = QtGui.QHBoxLayout()
		self.horizontalLayout_6.setObjectName(_fromUtf8("horizontalLayout_6"))
		self.label_7 = QtGui.QLabel(self.groupBox)
		self.label_7.setObjectName(_fromUtf8("label_7"))
		self.horizontalLayout_6.addWidget(self.label_7)
		self.comboBox_ChooseModel = QtGui.QComboBox(self.groupBox)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.comboBox_ChooseModel.sizePolicy().hasHeightForWidth())
		self.comboBox_ChooseModel.setSizePolicy(sizePolicy)
		self.comboBox_ChooseModel.setObjectName(_fromUtf8("comboBox_ChooseModel"))
		self.horizontalLayout_6.addWidget(self.comboBox_ChooseModel)
		self.verticalLayout_2.addLayout(self.horizontalLayout_6)
		self.horizontalLayout_8.addWidget(self.groupBox)
		self.verticalLayout_5 = QtGui.QVBoxLayout()
		self.verticalLayout_5.setObjectName(_fromUtf8("verticalLayout_5"))
		self.groupBox_2 = QtGui.QGroupBox(self.layoutWidget2)
		self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
		self.textBrowser_Instruction = QtGui.QTextBrowser(self.groupBox_2)
		self.textBrowser_Instruction.setGeometry(QtCore.QRect(5, 30, 141, 231))
		self.textBrowser_Instruction.setObjectName(_fromUtf8("textBrowser_Instruction"))
		self.verticalLayout_5.addWidget(self.groupBox_2)
		self.pushButton_RunFLAT = QtGui.QPushButton(self.layoutWidget2)
		self.pushButton_RunFLAT.setObjectName(_fromUtf8("pushButton_RunFLAT"))
		self.verticalLayout_5.addWidget(self.pushButton_RunFLAT)
		self.horizontalLayout_8.addLayout(self.verticalLayout_5)
		self.verticalLayout_6.addLayout(self.horizontalLayout_8)
		self.groupBox_3 = QtGui.QGroupBox(self.layoutWidget2)
		self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
		self.textEdit_Log = QtGui.QTextEdit(self.groupBox_3)
		#self.textEdit_Log.setGeometry(QtCore.QRect(10, 30, 641, 171))
		#zsd
		self.textEdit_Log.setGeometry(QtCore.QRect(10, 30, 890, 285))
		self.textEdit_Log.setObjectName(_fromUtf8("textEdit_Log"))
		self.verticalLayout_6.addWidget(self.groupBox_3)
		TabWidget.addTab(self.tab1, _fromUtf8(""))
		self.tab2 = QtGui.QWidget()
		self.tab2.setObjectName(_fromUtf8("tab2"))
		self.verticalLayout_7 = QtGui.QVBoxLayout(self.tab2)
		self.verticalLayout_7.setObjectName(_fromUtf8("verticalLayout_7"))
		self.horizontalLayout_13 = QtGui.QHBoxLayout()
		self.horizontalLayout_13.setObjectName(_fromUtf8("horizontalLayout_13"))
		self.verticalLayout_7.addLayout(self.horizontalLayout_13)
		self.horizontalLayout_9 = QtGui.QHBoxLayout()
		self.horizontalLayout_9.setObjectName(_fromUtf8("horizontalLayout_9"))
		self.verticalLayout_7.addLayout(self.horizontalLayout_9)
		self.label_8 = QtGui.QLabel(self.tab2)
		font = QtGui.QFont()
		font.setPointSize(20)
		font.setBold(False)
		font.setItalic(False)
		font.setWeight(50)
		self.label_8.setFont(font)
		self.label_8.setObjectName(_fromUtf8("label_8"))
		self.verticalLayout_7.addWidget(self.label_8)

		self.horizontalLayout_outputmodel = QtGui.QHBoxLayout() # output tab model selection
		self.horizontalLayout_outputmodel.setObjectName(_fromUtf8("horizontalLayout_2"))
		self.label_outputmodel = QtGui.QLabel(self.groupBox)
		self.label_outputmodel.setObjectName(_fromUtf8("label_outputmodel"))
		self.horizontalLayout_outputmodel.addWidget(self.label_outputmodel)
		self.comboBox_outputmodel = QtGui.QComboBox(self.tab2)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.comboBox_outputmodel.sizePolicy().hasHeightForWidth())
		self.comboBox_outputmodel.setSizePolicy(sizePolicy)
		self.comboBox_outputmodel.setObjectName(_fromUtf8("comboBox_outputmodel"))
		self.horizontalLayout_outputmodel.addWidget(self.comboBox_outputmodel)
		self.verticalLayout_7.addLayout(self.horizontalLayout_outputmodel)

		self.label_9 = QtGui.QLabel(self.tab2)
		self.label_9.setObjectName(_fromUtf8("label_9"))
		self.verticalLayout_7.addWidget(self.label_9)
		self.horizontalLayout_14 = QtGui.QHBoxLayout()
		self.horizontalLayout_14.setObjectName(_fromUtf8("horizontalLayout_14"))
		self.scrollArea = QtGui.QScrollArea(self.tab2)
		self.scrollArea.setAutoFillBackground(True)
		self.scrollArea.setWidgetResizable(True)
		self.scrollArea.setObjectName(_fromUtf8("scrollArea"))
		self.scrollAreaWidgetContents = QtGui.QWidget()
		self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 561, 253))
		self.scrollAreaWidgetContents.setObjectName(_fromUtf8("scrollAreaWidgetContents"))
		self.textEdit_ModelRes = QtGui.QTextEdit(self.scrollAreaWidgetContents)
		outputfont = QtGui.QFont("DejaVu Sans Mono")
		outputfont.setStyleHint(QFont.Monospace)
		self.textEdit_ModelRes.setFont(outputfont)
#		self.textEdit_ModelRes.setGeometry(QtCore.QRect(0, 0, 575, 297))
		#zsd
#		self.textEdit_ModelRes.setGeometry(QtCore.QRect(0, 0, 900, 497))
		self.textEdit_ModelRes.setGeometry(QtCore.QRect(0, 0, 820, 450))
		self.textEdit_ModelRes.setAutoFillBackground(True)
		self.textEdit_ModelRes.setObjectName(_fromUtf8("textEdit_ModelRes"))
		self.scrollArea.setWidget(self.scrollAreaWidgetContents)
		self.horizontalLayout_14.addWidget(self.scrollArea)
		self.pushButton_DownloadMD = QtGui.QPushButton(self.tab2)
		self.pushButton_DownloadMD.setObjectName(_fromUtf8("pushButton_DownloadMD"))
		self.horizontalLayout_14.addWidget(self.pushButton_DownloadMD)
		self.verticalLayout_7.addLayout(self.horizontalLayout_14)
		self.horizontalLayout_10 = QtGui.QHBoxLayout()
		self.horizontalLayout_10.setObjectName(_fromUtf8("horizontalLayout_10"))
		self.label_10 = QtGui.QLabel(self.tab2)
		self.label_10.setObjectName(_fromUtf8("label_10"))
		self.horizontalLayout_10.addWidget(self.label_10)
		self.pushButton_DownloadPD = QtGui.QPushButton(self.tab2)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.pushButton_DownloadPD.sizePolicy().hasHeightForWidth())
		self.pushButton_DownloadPD.setSizePolicy(sizePolicy)
		self.pushButton_DownloadPD.setObjectName(_fromUtf8("pushButton_DownloadPD"))
		self.horizontalLayout_10.addWidget(self.pushButton_DownloadPD)
		self.verticalLayout_7.addLayout(self.horizontalLayout_10)

		self.horizontalLayout_10_2 = QtGui.QHBoxLayout()
		self.horizontalLayout_10_2.setObjectName(_fromUtf8("horizontalLayout_10_2"))
		self.label_10_2 = QtGui.QLabel(self.tab2)
		self.label_10_2.setObjectName(_fromUtf8("label_10_2"))
		self.horizontalLayout_10_2.addWidget(self.label_10_2)
		self.pushButton_DownloadProj = QtGui.QPushButton(self.tab2)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.pushButton_DownloadProj.sizePolicy().hasHeightForWidth())
		self.pushButton_DownloadProj.setSizePolicy(sizePolicy)
		self.pushButton_DownloadProj.setObjectName(_fromUtf8("pushButton_DownloadProj"))
		self.horizontalLayout_10_2.addWidget(self.pushButton_DownloadProj)
		self.verticalLayout_7.addLayout(self.horizontalLayout_10_2)

		self.horizontalLayout_11 = QtGui.QHBoxLayout()
		self.horizontalLayout_11.setObjectName(_fromUtf8("horizontalLayout_11"))
		self.label_11 = QtGui.QLabel(self.tab2)
		self.label_11.setObjectName(_fromUtf8("label_11"))
		self.horizontalLayout_11.addWidget(self.label_11)
		self.pushButton_DownloadCM = QtGui.QPushButton(self.tab2)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.pushButton_DownloadCM.sizePolicy().hasHeightForWidth())
		self.pushButton_DownloadCM.setSizePolicy(sizePolicy)
		self.pushButton_DownloadCM.setObjectName(_fromUtf8("pushButton_DownloadCM"))
		self.horizontalLayout_11.addWidget(self.pushButton_DownloadCM)
		self.verticalLayout_7.addLayout(self.horizontalLayout_11)
		self.horizontalLayout_12 = QtGui.QHBoxLayout()
		self.horizontalLayout_12.setObjectName(_fromUtf8("horizontalLayout_12"))
		self.label_12 = QtGui.QLabel(self.tab2)
		self.label_12.setObjectName(_fromUtf8("label_12"))
		self.horizontalLayout_12.addWidget(self.label_12)
		self.pushButton_DownloadInstructions = QtGui.QPushButton(self.tab2)
		sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
		sizePolicy.setHorizontalStretch(0)
		sizePolicy.setVerticalStretch(0)
		sizePolicy.setHeightForWidth(self.pushButton_DownloadInstructions.sizePolicy().hasHeightForWidth())
		self.pushButton_DownloadInstructions.setSizePolicy(sizePolicy)
		self.pushButton_DownloadInstructions.setObjectName(_fromUtf8("pushButton_DownloadInstructions"))
		self.horizontalLayout_12.addWidget(self.pushButton_DownloadInstructions)
		self.verticalLayout_7.addLayout(self.horizontalLayout_12)
		TabWidget.addTab(self.tab2, _fromUtf8(""))

		## Map View Tab
		self.tab3 = QtGui.QWidget()
		self.tab3.setObjectName(_fromUtf8("tab3"))
		self.label_15 = QtGui.QLabel(self.tab3)
		self.label_15.setGeometry(QtCore.QRect(210, 0, 1000, 31))
		self.label_15.setObjectName(_fromUtf8("label_15"))
		self.comboBox_PicType = QtGui.QComboBox(self.tab3)
		#self.comboBox_PicType.setGeometry(QtCore.QRect(240, 420, 121, 27))
		#zsd
		self.comboBox_PicType.setGeometry(QtCore.QRect(240, 630, 200, 27))
		self.comboBox_PicType.setObjectName(_fromUtf8("comboBox_PicType"))
		self.layoutWidget3 = QtGui.QWidget(self.tab3)
		self.layoutWidget3.setGeometry(QtCore.QRect(10, 10, 149, 600))
		self.layoutWidget3.setObjectName(_fromUtf8("layoutWidget3"))
		self.gridLayout = QtGui.QGridLayout(self.layoutWidget3)
		self.gridLayout.setMargin(0)
		self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
		self.label_14 = QtGui.QLabel(self.layoutWidget3)
		self.label_14.setObjectName(_fromUtf8("label_14"))
		self.gridLayout.addWidget(self.label_14, 6, 0, 1, 1)
		self.label_13 = QtGui.QLabel(self.layoutWidget3)
		self.label_13.setObjectName(_fromUtf8("label_13"))
		self.gridLayout.addWidget(self.label_13, 2, 0, 1, 1)
		self.label_mapmodel = QtGui.QLabel(self.layoutWidget3)
		self.label_mapmodel.setObjectName(_fromUtf8("label_mapmodel"))
		self.gridLayout.addWidget(self.label_mapmodel, 0, 0, 1, 1)
		self.label_16 = QtGui.QLabel(self.layoutWidget3)
		self.label_16.setObjectName(_fromUtf8("label_16"))
		self.gridLayout.addWidget(self.label_16, 7, 0, 1, 1)
		#self.pushButton_GenNewMap = QtGui.QPushButton(self.layoutWidget3)
		#self.pushButton_GenNewMap.setObjectName(_fromUtf8("pushButton_GenNewMap"))
		#self.gridLayout.addWidget(self.pushButton_GenNewMap, 5, 0, 1, 1)
		self.comboBox_mapmodel = QtGui.QComboBox(self.layoutWidget3)
		self.comboBox_mapmodel.setObjectName(_fromUtf8("comboBox_mapmodel"))
		self.gridLayout.addWidget(self.comboBox_mapmodel, 1, 0, 1, 1)
		self.comboBox_DepVarMap = QtGui.QComboBox(self.layoutWidget3)
		self.comboBox_DepVarMap.setObjectName(_fromUtf8("comboBox_DepVarMap"))
		self.gridLayout.addWidget(self.comboBox_DepVarMap, 3, 0, 1, 1)
		self.comboBox_estproj = QtGui.QComboBox(self.layoutWidget3)
		self.comboBox_estproj.setObjectName(_fromUtf8("comboBox_estproj"))
		self.gridLayout.addWidget(self.comboBox_estproj, 5, 0, 1, 1)
		self.comboBox_estproj.addItems(["Estimated", "Projected"])
		self.pushButton_SaveMap = QtGui.QPushButton(self.tab3)
		self.label_estproj = QtGui.QLabel(self.layoutWidget3)
		self.label_estproj.setObjectName(_fromUtf8("label_estproj"))
		self.gridLayout.addWidget(self.label_estproj, 4, 0, 1, 1)
		#self.pushButton_SaveMap.setGeometry(QtCore.QRect(450, 420, 98, 27))
		#zsd
		self.compcheckbox = QCheckBox(self.layoutWidget3)
		self.compcheckbox.setText(QtGui.QApplication.translate("TabWidget", "Compare", None, QtGui.QApplication.UnicodeUTF8))
		self.gridLayout.addWidget(self.compcheckbox, 8, 0, 1, 1)
		self.comp_model = QtGui.QComboBox(self.layoutWidget3)
		self.gridLayout.addWidget(self.comp_model, 9, 0, 1, 1)
		self.comp_estproj = QtGui.QComboBox(self.layoutWidget3)
		self.gridLayout.addWidget(self.comp_estproj, 10, 0, 1, 1)
		self.label_comp = QtGui.QLabel(self.layoutWidget3)
		self.label_comp.setWordWrap(True)
		#self.label_comp.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body>Fraction difference for<br> comparisons is<br> calculated by<br> alternative model<br> fraction minus base<br> model fraction.</body></html>", None, QtGui.QApplication.UnicodeUTF8))
		self.gridLayout.addWidget(self.label_comp, 11, 0, 1, 1)
		self.comp_estproj.addItems(["Estimated", "Projected"])

		self.pushButton_SaveMap.setGeometry(QtCore.QRect(450, 630, 98, 27))
		self.pushButton_SaveMap.setObjectName(_fromUtf8("pushButton_SaveMap"))
		self.widget_Map = QtGui.QWidget(self.tab3)
		#self.widget_Map.setGeometry(QtCore.QRect(170, 20, 511, 401))
		self.widget_Map.setGeometry(QtCore.QRect(170, 20, 760, 611))
		self.widget_Map.setObjectName(_fromUtf8("widget_Map"))
		#self.layout_Map = QtGui.QVBoxLayout(self.tab3)
		#self.layout_Map.setGeometry(QtCore.QRect(180, 30, 471, 361))
		#self.layout_Map.setObjectName(_fromUtf8("layout_Map"))
		TabWidget.addTab(self.tab3, _fromUtf8(""))

		self.retranslateUi(TabWidget)
		TabWidget.setCurrentIndex(0)
		QtCore.QMetaObject.connectSlotsByName(TabWidget)

		#zsd-add some items in combo
		self.comboBox_dataset.addItems(['Default Maize Dataset','Default Multi-crop Dataset','Upload Dataset'])
		self.comboBox_GridSize.addItems(['%d by %d'%(i,i) for i in range(1,61)])
		self.comboBox_NumDepVars.addItems(['%d'%i for i in range(1,11)])
		self.comboBox_NumNDepVars.addItems(['%d'%i for i in range(1,51)])
		self.comboBox_ChooseModel.addItems(['Default (see Instruction to download model)', 'Upload User Defined Model'])
		self.pictypes = ['GeoTIFF', 'PNG (Screenshot)','JPG (Screenshot)']
		self.actualpictypes = {self.pictypes[0]: [False, "geotiff"], self.pictypes[1]: [True, "png"], self.pictypes[2]: [True, "jpg"]}
		self.comboBox_PicType.addItems(self.pictypes)
		self.lineEdit_ModelName.setText('Enter_new_job_name_here...')
		self.textBrowser_Instruction.setHtml('Click <a href="#anchor">here</a> to download default GAMS script, and default datasets for estimation and projection')
		#zsd--add signal or slots
		self.pushButton_RunFLAT.clicked.connect(self.RunFLAT)
		#self.pushButton_GenNewMap.clicked.connect(self.generateMap)
		self.pushButton_SaveMap.clicked.connect(self.saveCurrentMap)
		self.comboBox_dataset.currentIndexChanged.connect(self.SelectData)
		self.comboBox_projdataset.currentIndexChanged.connect(self.SelectProjData)
		self.comboBox_ChooseModel.currentIndexChanged.connect(self.SelectModel)
		self.comboBox_DepVarMap.currentIndexChanged.connect(self.ChangeCrop)
		self.comboBox_estproj.currentIndexChanged.connect(self.ChangeCrop)
		self.compcheckbox.stateChanged.connect(self.ChangeCrop)
		self.comp_model.currentIndexChanged.connect(self.ChangeCrop)
		self.comp_estproj.currentIndexChanged.connect(self.ChangeCrop)
		self.comboBox_outputmodel.currentIndexChanged.connect(self.changeoutputmodel)
		self.comboBox_mapmodel.currentIndexChanged.connect(self.changemapmodel)
		self.pushButton_DownloadMD.clicked.connect(self.download_estimate)
		self.pushButton_DownloadPD.clicked.connect(self.download_final)
		self.pushButton_DownloadProj.clicked.connect(self.download_proj)
		self.pushButton_DownloadCM.clicked.connect(self.download_covariance)
		self.textBrowser_Instruction.anchorClicked.connect(self.download_datasample)
		self.pushButton_DownloadInstructions.clicked.connect(self.download_instructions)
		#zsd--add map object
		self.gridlayout_Map = QtGui.QGridLayout(self.widget_Map)
		self.gridlayout_Map.setObjectName(_fromUtf8('gridlayout_Map'))
		self.frame_Map = QtGui.QFrame(self.widget_Map)
		self.frame_Map.setFrameShape(QtGui.QFrame.StyledPanel)
		self.frame_Map.setFrameShadow(QtGui.QFrame.Raised)
		self.frame_Map.setObjectName(_fromUtf8("frame_Map"))
		self.gridlayout_Map.addWidget(self.frame_Map, 0, 0, 1, 1)
		self.layout_Map = QtGui.QVBoxLayout(self.frame_Map)

		#create working directory & put a few staffs in the working directory
		self.SetupRunningDir()
		self.raster_crop = None
		self.use_user_gams = False

		# Create a Map Container, aka map canvas
#                self.map.canvas.setMapTool(pointtool)
		canvasProp = {'panControl':  True,
					  'panControlOptions':
								   {'style':'DEFAULT'},
					  'zoomControl': True,
					  'zoomControlOptions':
								   {'size': 'CUSTOM',
									'option': 'ZOOMIN, ZOOMOUT, ZOOMHOME'},
#                              'selectControl': True,
#                              'selectControlOptions':
#                                           {'size': 'CUSTOM',
#                                            'option': 'SINGLE, RECTANGLE, POLYGON, FREEHAND, RADIUS'},
					  'layerControl':  True,
					  # 'mapTipControl':True,
					  'pluginControl':'drawingtool',
					  'captureControl': True,
					  'customtool': {
						'name': "Lookup name of region",
						'icon': "stateicon.png",
						'tool': self.getpointtool
						}
					  }

		self.mapContainer = gabbs.maps.MapContainer(canvasProp)
		# Add canvas as a widget to the layout
		self.layout_Map.addWidget(self.mapContainer)

		#-85.508742, 46.120850
		#<lon>-86.9080556</lon><lat>40.4258333</lat>
		# Create a Map object
		mapProp = {'center':
				#{'lon': -86.208742,
					  {'lon': -16.208742,
						  #'lat': 39.820850},
					   'lat': 1.820850},
				   'zoom':    2,
				   'maxZoom': 18,
				   'minZoom': 1,
				   'mapTypeId': 'OSM'} #OSM #'GOOGLE_HYBRID'}
		self.map = gabbs.maps.Map(mapProp)
		self.mapContainer.addLayer(self.map)

		#color legend
		self.colorBarFrame = QFrame(iface.mapCanvas)
		self.colorBarFrame.setGeometry(QRect(4, 5, 476, 31))
		self.colorBarFrame.setObjectName(_fromUtf8("colorBarFrame"))

		self.colorBars = []
		self.color1 = QWidget(self.colorBarFrame)
		self.color1.setGeometry(QRect(20, 5, 44, 21))
		self.color1.setStyleSheet(_fromUtf8("background-color: #ccffff;"))
		self.color1.setObjectName(_fromUtf8("color1"))
		self.color2 = QWidget(self.colorBarFrame)
		self.color2.setGeometry(QRect(64, 5, 44, 21))
		self.color2.setStyleSheet(_fromUtf8("background-color: #00ff80;"))
		self.color2.setObjectName(_fromUtf8("color2"))
		self.color3 = QWidget(self.colorBarFrame)
		self.color3.setGeometry(QRect(108, 5, 44, 21))
		self.color3.setStyleSheet(_fromUtf8("background-color: #80ff00;"))
		self.color3.setObjectName(_fromUtf8("color3"))
		self.color4 = QWidget(self.colorBarFrame)
		self.color4.setGeometry(QRect(152, 5, 44, 21))
		self.color4.setStyleSheet(_fromUtf8("background-color: #ffff00;"))
		self.color4.setObjectName(_fromUtf8("color4"))
		self.color5 = QWidget(self.colorBarFrame)
		self.color5.setGeometry(QRect(196, 5, 44, 21))
		self.color5.setStyleSheet(_fromUtf8("background-color: #ff8000;"))
		self.color5.setObjectName(_fromUtf8("color5"))
		self.color6 = QWidget(self.colorBarFrame)
		self.color6.setGeometry(QRect(240, 5, 44, 21))
		self.color6.setStyleSheet(_fromUtf8("background-color: #ff0000;"))
		self.color6.setObjectName(_fromUtf8("color6"))

		self.colorBars.append(self.color1)
		self.colorBars.append(self.color2)
		self.colorBars.append(self.color3)
		self.colorBars.append(self.color4)
		self.colorBars.append(self.color5)
		self.colorBars.append(self.color6)

		self.legendValues = []
		self.l0 = QLabel(self.colorBarFrame)
		self.l0.setGeometry(QRect(22+10, 7, 41, 16))
		self.l0.setObjectName(_fromUtf8("l0"))
		self.l1 = QLabel(self.colorBarFrame)
		self.l1.setGeometry(QRect(55+10, 7, 41, 16))
		self.l1.setObjectName(_fromUtf8("l1"))
		self.l2 = QLabel(self.colorBarFrame)
		self.l2.setGeometry(QRect(99+10, 7, 41, 16))
		self.l2.setObjectName(_fromUtf8("l2"))
		self.l3 = QLabel(self.colorBarFrame)
		self.l3.setGeometry(QRect(143+10, 7, 41, 16))
		self.l3.setObjectName(_fromUtf8("l3"))
		self.l4 = QLabel(self.colorBarFrame)
		self.l4.setGeometry(QRect(187+10, 7, 41, 16))
		self.l4.setObjectName(_fromUtf8("l4"))
		self.l5 = QLabel(self.colorBarFrame)
		self.l5.setGeometry(QRect(231+10, 7, 41, 16))
		self.l5.setObjectName(_fromUtf8("l5"))


		self.legendValues.append(self.l0)
		self.legendValues.append(self.l1)
		self.legendValues.append(self.l2)
		self.legendValues.append(self.l3)
		self.legendValues.append(self.l4)
		self.legendValues.append(self.l5)


		self.diffcolorBarFrame = QFrame(iface.mapCanvas)
		self.diffcolorBarFrame.setGeometry(QRect(4, 5, 476, 31))
		diffcolors = [["-0.55", "660000", False], ["-0.1", "ff0000", False], ["0", "ffffff", False], ["0.1", "00ff00", False], ["0.55", "006600", False], ["pixels not in common", "666666", True]]
		x = 20
		for val, col, iswide in diffcolors:
			color1 = QWidget(self.diffcolorBarFrame)
			color1.setGeometry(QRect(x, 5, 150 if iswide else 44, 21))
			color1.setStyleSheet(_fromUtf8("background-color: #" + col + ";"))
			l1 = QLabel(self.diffcolorBarFrame)
			l1.setGeometry(QRect(x+1, 7, 150 if iswide else 41, 16))
			l1.setText(str(val))
			l1.setStyleSheet('color: black;')

			x += 44

		self.hideColorBarFrame()

		filePath = '%s/regions.xml'%FLAT_DIR
		rasterProp = {"layerName":     "Borders",
					  "opacity": 0.5}
		rasterProp["fileName"] = filePath
		self.raster_country = gabbs.maps.Raster(rasterProp)
		self.mapContainer.addLayer(self.raster_country)
		gabbs.maps.setCurrentLayer(self.raster_country.layer.id())

#                self.GenerateVisualized(["test"])

		self.SelectData()
		self.resetmap()
		self.updatemodels()

	def getpointtool(self, canvas):
		self.pointtool = PointTool(canvas, self.onmapclicked)
		return self.pointtool

	def onmapclicked(self, point):
		self.label_15.setText(QtGui.QApplication.translate("TabWidget", "Loading...", None, QtGui.QApplication.UnicodeUTF8))
		self.countyfinder = countyFinder(point)
		self.countyfinder.connect(self.countyfinder, SIGNAL("findcounty"), self.findcounty)
		self.countyfinder.start()

	def findcounty(self, data):
		country, state, county = data
		print data
		text = country + ", " + state + ", " + county
		self.label_15.setText(QtGui.QApplication.translate("TabWidget", text, None, QtGui.QApplication.UnicodeUTF8))

	#zsd -- self defined slot functions
	def clearLegendValues(self):
		for i in range(0,6):
			self.legendValues[i].setText(_translate("Widget", "", None))

	def setLegendValues(self):
		vals = [0, 0.1, 0.2, 0.3, 0.4, 0.5]
		for i in range(0,6):
			#self.legendValues[i].setText(_translate('Widget', str(vals[i]), None))
			self.legendValues[i].setText(str(vals[i]))
			self.legendValues[i].setStyleSheet('color: black;')

	def showColorBarFrame(self):
#		for i in range(6):
#			self.colorBars[i].show()
		self.colorBarFrame.show()

	def showDiffColorBarFrame(self):
		self.diffcolorBarFrame.show()

	def hideColorBarFrame(self):
		self.colorBarFrame.hide()
		self.diffcolorBarFrame.hide()

	def download_instructions(self):
		file_path = os.path.expanduser('%s/instructions.pdf'%(FLAT_DIR))
		if os.path.isfile(file_path):
			process_download(file_path)
		else:
			QtGui.QMessageBox.warning(self.tab1, "Error", "Does not have instruction documents.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)


	def download_datasample(self, argv1):
		file_path = os.path.expanduser('%s/flat_sample.zip'%(FLAT_DIR))
		if os.path.isfile(file_path):
			process_download(file_path)
		else:
			QtGui.QMessageBox.warning(self.tab1, "Error", "Does not have data samples.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)


	def SelectData(self):
		dt = str(self.comboBox_dataset.currentText())
		if dt == 'Upload Dataset':
			user_data = '%s/userdata.csv'%FLAT_DIR
			process_upload(user_data)

			self.comboBox_GridSize.setEnabled(True)
			self.comboBox_NumDepVars.setEnabled(True)
			self.comboBox_NumNDepVars.setEnabled(True)

			self.comboBox_projdataset.clear()
			self.comboBox_projdataset.addItems(['Default Projection Dataset for Maize for the Americas','Default Projection Dataset for Multi-crop for the Americas','Upload Dataset'])
		else:
			self.comboBox_GridSize.setEnabled(False)
			self.comboBox_NumDepVars.setEnabled(False)
			self.comboBox_NumNDepVars.setEnabled(False)
			if dt == "Default Maize Dataset":
				self.comboBox_GridSize.setCurrentIndex(4)
				self.comboBox_NumDepVars.setCurrentIndex(0)
				self.comboBox_NumNDepVars.setCurrentIndex(26)

				self.comboBox_projdataset.clear()
				self.comboBox_projdataset.addItems(['Default Projection Dataset for Maize for the Americas','Upload Dataset'])
			elif dt == "Default Multi-crop Dataset":
				self.comboBox_GridSize.setCurrentIndex(4)
				self.comboBox_NumDepVars.setCurrentIndex(2)
				self.comboBox_NumNDepVars.setCurrentIndex(14)

				self.comboBox_projdataset.clear()
				self.comboBox_projdataset.addItems(['Default Projection Dataset for Multi-crop for the Americas','Upload Dataset'])

	def SelectProjData(self):
		dt = str(self.comboBox_projdataset.currentText())
		if dt == 'Upload Dataset':
			user_data = '%s/userprojdata.csv'%FLAT_DIR
			process_upload(user_data)

	def SetCacheDir(self, wms_xml, cache_dir):
		replace_file(wms_xml, 'CACHEPATH', cache_dir)

	def SetupRunningDir(self):
		self.script_dir = os.path.dirname(sys.argv[0])
		if not os.path.exists(FLAT_DIR):
			os.mkdir(FLAT_DIR)
		else:
						pass
#			os.system('rm -f %s/*'%(FLAT_DIR))
		os.system('cp -r %s %s'%(os.path.join(self.script_dir, "resource/*"), FLAT_DIR))
		os.system('cp %s %s'%(os.path.join(self.script_dir, "*.R"), FLAT_DIR))
		#set up WMS cache directory
		self.SetCacheDir('%s/provinces.xml'%FLAT_DIR, '%s/gdalwmscache'%FLAT_DIR)
		self.SetCacheDir('%s/countries.xml'%FLAT_DIR, '%s/gdalwmscache'%FLAT_DIR)
		self.SetCacheDir('%s/gadm28.xml'%FLAT_DIR, '%s/gdalwmscache'%FLAT_DIR)
		self.SetCacheDir('%s/regions.xml'%FLAT_DIR, '%s/gdalwmscache'%FLAT_DIR)

	def getoutputmodel(self):
		model = str(self.comboBox_outputmodel.currentText())
		if model == None or model == "":
			return
		return model

	def changeoutputmodel(self):
		model = self.getoutputmodel()
		if model == None: return
		self.textEdit_ModelRes.setText(self.get_estimate(model))

	def getmapmodel(self):
		model = str(self.comboBox_mapmodel.currentText())
		if model == None or model == "":
			return
		return model

	def getcompmapmodel(self):
		model = str(self.comp_model.currentText())
		if model == None or model == "":
			return
		return model

	def getparams(self, model):
		return pickle.load(open(outputpath(FLAT_DIR, model, "params.p"), "rb"))

	def changemapmodel(self):
		model = self.getmapmodel()
		if model == None: return
		modelparams = self.getparams(model)
		crops = self.getparams(model)["crops"]
		self.GenerateVisualized(crops)

	def get_estimate(self, model):
		path = outputpath(FLAT_DIR, model, "estimates.dat")
		print path
		if os.path.isfile(path):
			with open(path, 'r') as f:
				co = f.read()
			return co
		return None

	def getrasterpath(self, model, crop, isestimated):
		prefix = "out-proj-"
		if isestimated:
			print "ESTIMATED"
			prefix = "out-est-"
		raster_path = outputpath(FLAT_DIR, model, prefix + crop + ".tif")
		return raster_path

	def ChangeCrop(self):
		compare = self.compcheckbox.isChecked()

		self.comp_model.setEnabled(compare)
		self.comp_estproj.setEnabled(compare)


		crop = str(self.comboBox_DepVarMap.currentText())
		if crop == "":
			return

		raster_path_base = self.getrasterpath(self.getmapmodel(), crop, (str(self.comboBox_estproj.currentText()) == "Estimated"))
		raster_path_comp = self.getrasterpath(self.getcompmapmodel(), crop, (str(self.comp_estproj.currentText()) == "Estimated"))

		print 'current crop ', crop
		self.hideColorBarFrame()
		print raster_path_base
		print raster_path_comp, "Comp"

		if self.raster_crop:
			gabbs.maps.gbsRemoveLayer(self.raster_crop)
			self.raster_crop = None

		raster_path = None
		if compare:
			if os.path.exists(raster_path_comp):
				baseparams = self.getparams(self.getmapmodel())
				compparams = self.getparams(self.getcompmapmodel())

				if baseparams["grid_siz"] == compparams["grid_siz"]:
					print raster_path_base, raster_path_comp
					print os.path.exists(raster_path_base), os.path.exists(raster_path_comp)
					rasterdiff(raster_path_base, raster_path_comp)
					raster_path = "diff.tif"
		else:
			raster_path = raster_path_base

		self.raster_path = None
		if raster_path != None and os.path.exists(raster_path):
			self.raster_path = raster_path

			stylepath = os.path.expanduser('%s/crop-color.qml'%FLAT_DIR)
			if compare:
				stylepath = os.path.expanduser('%s/diff.qml'%FLAT_DIR)

			rasterProp = {"layerName":     crop,
				"useCostumStyle": True,
				"useCustomStyle": True,
				"styleFileName": stylepath}
			rasterProp["fileName"] = raster_path
			self.raster_crop = gabbs.maps.Raster(rasterProp)
			self.mapContainer.addLayer(self.raster_crop)
			self.map.canvas.refresh()
			if not compare:
				self.setLegendValues()
				self.showColorBarFrame()
				self.label_comp.setText(QtGui.QApplication.translate("TabWidget", "", None, QtGui.QApplication.UnicodeUTF8))
			else:
				self.showDiffColorBarFrame()

				basetext = (self.getmapmodel() or "?") + " " + str(self.comboBox_estproj.currentText())
				alttext = (self.getcompmapmodel() or "?") + " " + str(self.comp_estproj.currentText())
				# <font color=\"#660000\">" + basetext + " &gt; " + alttext + "</font><br><font color=\"#006600\">" + basetext + " &lt; " + alttext + "</font>
				self.label_comp.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body>Result equals " + basetext + " minus " + alttext + "</body></html>", None, QtGui.QApplication.UnicodeUTF8))
			#print self.mapContainer.canvas.setLayerSet
			#self.mapContainer.canvas.setLayerSet([QgsMapCanvasLayer(self.raster_crop.getLayer())])

	def SelectModel(self):
		md = str(self.comboBox_ChooseModel.currentText())
		if md == 'Upload User Defined Model':
			user_model = '%s/USERMODEL.gms'%FLAT_DIR
			process_upload(user_model)
			self.use_user_gams = True
		else:
			self.use_user_gams = False

	def download_estimate(self):
		model_name = self.getoutputmodel()
		file_path = outputpath(FLAT_DIR, model_name, "estimates.dat")
		if os.path.isfile(file_path):
			process_download(file_path)
		else:
			QtGui.QMessageBox.warning(self.tab2, "Error", "Does not have results.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)

	def download_covariance(self):
		model_name = self.getoutputmodel()
		file_path = outputpath(FLAT_DIR, model_name, "covariances.dat")
		if os.path.isfile(file_path):
			process_download(file_path)
		else:
			QtGui.QMessageBox.warning(self.tab2, "Error", "Does not have results.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)

	def download_final(self):
		model_name = self.getoutputmodel()
		file_path = outputpath(FLAT_DIR, model_name, "finalresults.dat")
		if os.path.isfile(file_path):
			process_download(file_path)
		else:
			QtGui.QMessageBox.warning(self.tab2, "Error", "Does not have results.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)

	def download_proj(self):
		model_name = self.getoutputmodel()
		file_path = outputpath(FLAT_DIR, model_name, "projectionresults.dat")
		if os.path.isfile(file_path):
			process_download(file_path)
		else:
			QtGui.QMessageBox.warning(self.tab2, "Error", "Does not have results.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)

	#saved the current map
	def saveCurrentMap(self):
		#autmoatically remove the drawing bounding box
		'''
		gabbs.maps.gbsRemoveDrawingBounds()
		if app != None:
			app.processEvents()
		#save image
		image_type = str(self.comboBox_PicType.currentText()).lower()
		self.mapContainer.takeScreenshot_v2(os.path.expanduser(FLAT_DIR), image_type)
		'''

		'''
		image_type = 'png'
		tempPath = os.path.expanduser(FLAT_DIR)
		p = QPixmap.grabWindow(iface.mapCanvas.winId())
		p.save(tempPath + "/img." + image_type, image_type)

		# print "imageDownload1"
		call(["/usr/bin/exportfile", tempPath + "/img." + image_type])
		# print "done"
		'''

		isscreenshot, image_type = self.actualpictypes[str(self.comboBox_PicType.currentText())]

		if isscreenshot:
			self.generateMap()
			gabbs.maps.gbsRemoveDrawingBounds()
			if app != None:
				app.processEvents()

			def initialrefresh():
				self.map.canvas.mapCanvasRefreshed.disconnect(initialrefresh)
				def newrenderComplete():
					print "Render complete"
					self.mapContainer.takeScreenshot_v2(os.path.expanduser(FLAT_DIR), image_type)
					self.map.canvas.mapCanvasRefreshed.disconnect(newrenderComplete)
				self.map.canvas.mapCanvasRefreshed.connect(newrenderComplete)
				self.map.canvas.refreshAllLayers()
			self.map.canvas.mapCanvasRefreshed.connect(initialrefresh)
		else:
			crop = str(self.comboBox_DepVarMap.currentText())
			print 'current crop ', crop
#			raster_path = os.path.expanduser(FLAT_DIR + '/out-%s.tif'%crop)
			raster_path = self.raster_path
			if raster_path == None:
				return

			box = gabbs.maps.gbsGetDrawingBounds()
			crsTransform = self.map.createCrsTransform()
			if box:
				lonFrom = gabbs.maps.gbsGetDrawingBounds().topLeft().x()
				latFrom = gabbs.maps.gbsGetDrawingBounds().topLeft().y()
				lonTo = gabbs.maps.gbsGetDrawingBounds().bottomRight().x()
				latTo = gabbs.maps.gbsGetDrawingBounds().bottomRight().y()

				"""
				print lonFrom, latFrom, lonTo, latTo

				xFrom, yFrom = crsTransform.transform(QgsPoint(lonFrom, latFrom), QgsCoordinateTransform.ForwardTransform)
				xTo, yTo = crsTransform.transform(QgsPoint(lonTo, latTo), QgsCoordinateTransform.ForwardTransform)

				tmpfilepath = "/tmp/out-%s.tif"%crop
				if os.path.exists(tmpfilepath):
					os.remove(tmpfilepath)
				print xFrom, yFrom, xTo, yTo
				p = subprocess.Popen(["gdalwarp", "-t_srs", "EPSG:900913", "-te", str(xFrom), str(yFrom), str(xTo), str(yTo), raster_path, tmpfilepath])
				p.wait()
				raster_path = tmpfilepath
				"""

				tmpfilepath = "/tmp/out-%s.tif"%crop

				cropraster(raster_path, tmpfilepath, [lonFrom, latFrom, lonTo, latTo])

				raster_path = tmpfilepath

			else:
				pass
#				rect = self.map.canvas.fullExtent().toRectF()
#				xFrom, yFrom, xTo, yTo = rect.topLeft().x(), rect.topLeft().y(), rect.bottomRight().x(), rect.bottomRight().y()
#			print xFrom, yFrom, xTo, yTo

			subprocess.Popen(["/usr/bin/exportfile", raster_path])

	#zoom to the bounding boxes selected by the user
	def generateMap(self):
		box = gabbs.maps.gbsGetDrawingBounds()
		if box:
			print box
		else:
			print 'No region is selected'
			self.map.canvas.refresh()
			return
		# QgsRectangle
		lonFrom = gabbs.maps.gbsGetDrawingBounds().topLeft().x()
		latFrom = gabbs.maps.gbsGetDrawingBounds().topLeft().y()
		lonTo = gabbs.maps.gbsGetDrawingBounds().bottomRight().x()
		latTo = gabbs.maps.gbsGetDrawingBounds().bottomRight().y()

		print lonFrom, latFrom, lonTo, latTo
		center_lon = (lonFrom + lonTo)/2
		center_lat = (latFrom + latTo)/2;
		print center_lon, center_lat
		crsTransform = self.map.createCrsTransform()
		centerPoint = crsTransform.transform(QgsPoint(center_lon, center_lat), QgsCoordinateTransform.ForwardTransform)
		topLeftPoint = crsTransform.transform(QgsPoint(lonFrom, latFrom), QgsCoordinateTransform.ForwardTransform)
		bottomRightPoint = crsTransform.transform(QgsPoint(lonTo, latTo), QgsCoordinateTransform.ForwardTransform)
		self.map.canvas.setCenter(centerPoint)
		self.map.mapCenterPoint = centerPoint
		rect = QgsRectangle(topLeftPoint, bottomRightPoint)
		self.map.canvas.setExtent(rect)
		self.map.canvas.refresh()

	defaultzoom = None
	def resetmap(self):
		self.map.canvas.setCenter(self.map.centerPoint)
		# self.map.canvas.zoomToFullExtent()
		if not self.defaultzoom and iface.mapZoomScale:
			self.defaultzoom = iface.mapZoomScale
		if self.defaultzoom:
			iface.mapCanvas.zoomScale(self.defaultzoom)


	def GenerateVisualized(self, crops):
		self.comboBox_DepVarMap.clear()
		self.comboBox_DepVarMap.addItems(crops)

	def appendLogMessage(self, text):
		scrollbar = self.textEdit_Log.verticalScrollBar()
		currentvalue = scrollbar.value()
		isatend = (currentvalue == scrollbar.maximum())

		if str(self.textEdit_Log.toPlainText()) == "":
			self.textEdit_Log.document().setPlainText(str(text))
		else:
			self.textEdit_Log.document().setPlainText(str(self.textEdit_Log.toPlainText()) + "\n" + str(text))

		if isatend:
			scrollbar.setValue(scrollbar.maximum())
		else:
			scrollbar.setValue(currentvalue)

		if app != None:
			app.processEvents()

	def ClearPreviousCropFractionLayers(self):
		self.comboBox_DepVarMap.clear()
		self.hideColorBarFrame()
		if self.raster_crop:
			gabbs.maps.gbsRemoveLayer(self.raster_crop)
			self.raster_crop = None

	def retranslateUi(self, TabWidget):
		TabWidget.setWindowTitle(QtGui.QApplication.translate("TabWidget", "FLAT in the Cloud", None, QtGui.QApplication.UnicodeUTF8))
		self.groupBox.setTitle(QtGui.QApplication.translate("TabWidget", "Inputs", None, QtGui.QApplication.UnicodeUTF8))
		self.label.setText(QtGui.QApplication.translate("TabWidget", "Model Name", None, QtGui.QApplication.UnicodeUTF8))
		self.label_2.setText(QtGui.QApplication.translate("TabWidget", "Choose Dataset for Estimation", None, QtGui.QApplication.UnicodeUTF8))
		self.label_proj.setText(QtGui.QApplication.translate("TabWidget", "Choose Dataset for Projection", None, QtGui.QApplication.UnicodeUTF8))
		self.label_3.setText(QtGui.QApplication.translate("TabWidget", "Choose Grid Size (lon/lat minute)", None, QtGui.QApplication.UnicodeUTF8))
		self.label_6.setText(QtGui.QApplication.translate("TabWidget", "Variables", None, QtGui.QApplication.UnicodeUTF8))
		self.label_4.setText(QtGui.QApplication.translate("TabWidget", "No. of Dependent Variables", None, QtGui.QApplication.UnicodeUTF8))
		self.label_5.setText(QtGui.QApplication.translate("TabWidget", "No. of Independent Variables", None, QtGui.QApplication.UnicodeUTF8))
		self.label_7.setText(QtGui.QApplication.translate("TabWidget", "Choose Model", None, QtGui.QApplication.UnicodeUTF8))
		self.groupBox_2.setTitle(QtGui.QApplication.translate("TabWidget", "Instruction", None, QtGui.QApplication.UnicodeUTF8))
		self.pushButton_RunFLAT.setText(QtGui.QApplication.translate("TabWidget", "Run FLAT and Visualize/\n"
"Download Results", None, QtGui.QApplication.UnicodeUTF8))
		self.groupBox_3.setTitle(QtGui.QApplication.translate("TabWidget", "Log", None, QtGui.QApplication.UnicodeUTF8))
		TabWidget.setTabText(TabWidget.indexOf(self.tab1), QtGui.QApplication.translate("TabWidget", "Model Set-up", None, QtGui.QApplication.UnicodeUTF8))
		self.label_8.setText(QtGui.QApplication.translate("TabWidget", "Model Results", None, QtGui.QApplication.UnicodeUTF8))
		self.label_outputmodel.setText(QtGui.QApplication.translate("TabWidget", "Select Model:", None, QtGui.QApplication.UnicodeUTF8))
		self.label_9.setText(QtGui.QApplication.translate("TabWidget", "Coefficient estimates and standard errors", None, QtGui.QApplication.UnicodeUTF8))
		self.pushButton_DownloadMD.setText(QtGui.QApplication.translate("TabWidget", "Download", None, QtGui.QApplication.UnicodeUTF8))
		self.label_10.setText(QtGui.QApplication.translate("TabWidget", "Estimated Dependent Variable Fractions by Pixel", None, QtGui.QApplication.UnicodeUTF8))
		self.label_10_2.setText(QtGui.QApplication.translate("TabWidget", "Projected Dependent Variable Fractions by Pixel", None, QtGui.QApplication.UnicodeUTF8))
		self.pushButton_DownloadPD.setText(QtGui.QApplication.translate("TabWidget", "Download", None, QtGui.QApplication.UnicodeUTF8))
		self.pushButton_DownloadProj.setText(QtGui.QApplication.translate("TabWidget", "Download", None, QtGui.QApplication.UnicodeUTF8))
		self.label_11.setText(QtGui.QApplication.translate("TabWidget", "Covariance Matrix for Parameter Estimates", None, QtGui.QApplication.UnicodeUTF8))
		self.pushButton_DownloadCM.setText(QtGui.QApplication.translate("TabWidget", "Download", None, QtGui.QApplication.UnicodeUTF8))
		self.label_12.setText(QtGui.QApplication.translate("TabWidget", "Instructions for Calculations of Marginal Effects and Odds Ratio", None, QtGui.QApplication.UnicodeUTF8))
		self.pushButton_DownloadInstructions.setText(QtGui.QApplication.translate("TabWidget", "Download", None, QtGui.QApplication.UnicodeUTF8))
		TabWidget.setTabText(TabWidget.indexOf(self.tab2), QtGui.QApplication.translate("TabWidget", "Model Results", None, QtGui.QApplication.UnicodeUTF8))
#        self.label_15.setText(QtGui.QApplication.translate("TabWidget", "", None, QtGui.QApplication.UnicodeUTF8))
		self.label_14.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body>Use the \"Drawing tool\"<br> (blue box icon) to<br> crop when saving map.</body></html>", None, QtGui.QApplication.UnicodeUTF8))
		self.label_13.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body>Select Dependent<br>Variable to Map:</body></html>", None, QtGui.QApplication.UnicodeUTF8))
		self.label_mapmodel.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body>Select Model:</body></html>", None, QtGui.QApplication.UnicodeUTF8))
		self.label_estproj.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body>Select Estimated<br>or Projected<br>Fractions to Map:</body></html>", None, QtGui.QApplication.UnicodeUTF8))
		self.label_16.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body>To use the drawing tool,<br>use left mouse button<br>to select two corners<br>of a bounding box.<br>Use right mouse button<br>to clear.</body></html>", None, QtGui.QApplication.UnicodeUTF8))
#        self.pushButton_GenNewMap.setText(QtGui.QApplication.translate("TabWidget", "Generate New Map", None, QtGui.QApplication.UnicodeUTF8))
		self.pushButton_SaveMap.setText(QtGui.QApplication.translate("TabWidget", "Save Map", None, QtGui.QApplication.UnicodeUTF8))
		TabWidget.setTabText(TabWidget.indexOf(self.tab3), QtGui.QApplication.translate("TabWidget", "Visualize Results", None, QtGui.QApplication.UnicodeUTF8))

	def getmodels(self):
		folder = FLAT_DIR + "/output"
		if os.path.exists(folder):
			return os.listdir(folder)
		else:
			return []

	def updatemodels(self, modelname=None):
		models = self.getmodels()
		if modelname != None:
			if modelname in models:
				models.remove(modelname)
				models = [modelname] + models

		self.comboBox_outputmodel.clear()
		self.comboBox_outputmodel.addItems(models)
		self.comboBox_mapmodel.clear()
		self.comboBox_mapmodel.addItems(models)
		self.comp_model.clear()
		self.comp_model.addItems(models)

	def RunFLAT(self):
		global running_flat
		if running_flat:
				return

		self.resetmap()

		self.appendLogMessage("Starting\n")
		model_name = str(self.lineEdit_ModelName.text())
		if model_name.find('Enter_new_job_name_here') != -1:
			QtGui.QMessageBox.warning(self.tab1, "Error", "Please specify your model name.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)
			return

		print 'I will run Rscript in the backend'
		#dataset chosed
		dt = str(self.comboBox_dataset.currentText())
		if dt == 'Default Maize Dataset':
			data_file = 'defaultmaize.csv'
		elif dt == 'Default Multi-crop Dataset':
			data_file = 'defaultmulticrop.csv'
		else:
			data_file = 'userdata.csv'
		dt = str(self.comboBox_projdataset.currentText())
		if dt == 'Default Projection Dataset for Maize for the Americas':
			data_file_proj = 'defaultmaizeforprojection.csv'
		elif dt == 'Default Projection Dataset for Multi-crop for the Americas':
			data_file_proj = 'defaultmulticropforprojection.csv'
		else:
			data_file_proj = 'userprojdata.csv'
		#check whether input files exist
		if not os.path.isfile('%s/%s'%(FLAT_DIR, data_file)):
			QtGui.QMessageBox.warning(self.tab1, "Error", "Does not have input estimation csv files, check program!", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)
		if not os.path.isfile('%s/%s'%(FLAT_DIR, data_file_proj)):
			QtGui.QMessageBox.warning(self.tab1, "Error", "Does not have input projection csv files, check program!", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)
		if self.use_user_gams and not os.path.isfile('%s/USERMODEL.gms'%FLAT_DIR) or not self.use_user_gams and not os.path.isfile('%s/FLAT.gms'%FLAT_DIR):
			QtGui.QMessageBox.warning(self.tab1, "Error", "Does not have input GAMS script, check program!", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)


		#selected Grid Size
		grid_siz = str(self.comboBox_GridSize.currentText())
		grid_siz = grid_siz.split(' ')[0]
		#No. of Dependent Variables
		ndep = str(self.comboBox_NumDepVars.currentText())
		#No. of InDependent Variables
		nidep = str(self.comboBox_NumNDepVars.currentText())
		#run FLAT
		self.textEdit_Log.clear()
		self.ClearPreviousCropFractionLayers()
		model_name = self.lineEdit_ModelName.text()

		running_flat = True
		self.pushButton_RunFLAT.setEnabled(False)

		self.flatworker = flatWorker(self, grid_siz, ndep, nidep, self.use_user_gams, data_file, data_file_proj, model_name)
		self.flatworker.connect(self.flatworker, SIGNAL("log(QString)"), self.appendLogMessage)
		self.flatworker.connect(self.flatworker, SIGNAL("clear"), self.textEdit_Log.clear)
		self.flatworker.connect(self.flatworker, SIGNAL("updatemodels"), self.updatemodels)
#		self.flatworker.connect(self.flatworker, SIGNAL("model"), self.textEdit_ModelRes.setText)
#		self.flatworker.connect(self.flatworker, SIGNAL("generatevisualized"), self.GenerateVisualized)
		self.flatworker.connect(self.flatworker, SIGNAL("finished()"), self.finishflat)
		self.flatworker.start()

	def finishflat(self):
		global running_flat
		running_flat = False
		self.pushButton_RunFLAT.setEnabled(True)

class flatWorker(QThread):
	def __init__(self, app, grid_siz, ndep, nidep, use_user_gams, data_file, data_file_proj, model_name):
		QThread.__init__(self)

		self.app, self.grid_siz, self.ndep, self.nidep, self.use_user_gams, self.data_file, self.data_file_proj, self.model_name = app, grid_siz, ndep, nidep, use_user_gams, data_file, data_file_proj, model_name

	def __del__(self):
		self.wait()

	def run(self):
		flat = FLAT(FLAT_DIR)
		outR,outG = flat.run('%s/%s'%(FLAT_DIR, self.data_file), '%s/%s'%(FLAT_DIR, self.data_file_proj), self.grid_siz, self.ndep , self.nidep, self.use_user_gams, self.appendLogMessage)
		#RForFlatR failed
		if outG.find('Not Executed') != -1:
			return
		else:
			self.clear()
			self.appendLogMessage('Starting...')
			self.appendLogMessage('Running RForFLAT.R...')
			self.appendLogMessage('Running GAMS program...')
			#Gams running failed
			if outG.find('Status: Normal completion') == -1:
				self.appendLogMessage('Failed')
				msg = '\n=====DEBUG INFO=====\n'
				msg = msg + '[RForFLAT.R]\n' + outR + '\n'
				msg = msg + '\n\n[GAMS]\n' + outG
				self.appendLogMessage(msg)
				return

		#load the results
#		estimates = flat.get_estimate()
#		print estimates
#		if estimates:
#			self.model(estimates)
		#change result file name to append model name as a suffix
		flat.change_result_file_name(outputpath, self.model_name)
		#fulfill the items in "dependent variables" in 3rd Tab
		crops = self.GetCrops()
		print crops
		self.appendLogMessage('Generating crop fraction layers...')
		msg = '\n\n=====DEBUG INFO=====\n'
		msg = msg + '[RForFLAT.R]\n' + outR + '\n'
		msg = msg + '\n\n[GAMS]\n' + outG
		self.appendLogMessage(msg)
		outC = flat.generate_map(outputpath(FLAT_DIR, self.model_name, "finalresults.dat"), outputpath, self.model_name, "out-est-", crops, self.appendLogMessage)
		outC += flat.generate_map(outputpath(FLAT_DIR, self.model_name, "projectionresults.dat"), outputpath, self.model_name, "out-proj-", crops, self.appendLogMessage)
		self.clear()
		self.appendLogMessage('Starting...')
		self.appendLogMessage('Running RForFLAT.R...')
		self.appendLogMessage('Running GAMS program...')
		self.appendLogMessage('Generating crop fraction layers...')
		self.appendLogMessage('Finished!')
		msg = '\n=====DEBUG INFO=====\n'
		msg = msg + '[RForFLAT.R]\n' + outR + '\n'
		msg = msg + '\n\n[GAMS]\n' + outG
		msg = msg + '\n\n[CropFraction]\n' + outC
		self.appendLogMessage(msg)

		params = {"crops":crops, "grid_siz":self.grid_siz, "ndep":self.ndep, "nidep":self.nidep}
		paramfile = open(outputpath(FLAT_DIR, self.model_name, "params.p"), "wb")
		pickle.dump(params, paramfile)

#		self.generatevisualized(crops)
		self.updatemodels(self.model_name)
		self.appendLogMessage("\nDone.")

	#read the results in FLAT_DIR and generate the .tif files and fill the variables in third Tab
	def GetCrops(self):
		crop_names = 'cropnames.csv'
		items = []
		with open(os.path.expanduser(FLAT_DIR + '/' + crop_names), 'r') as f:
			for line in f:
				items.append(line.strip()[1:-1])
		return items

	def appendLogMessage(self, text):
		self.emit(SIGNAL("log(QString)"), text)
	def clear(self):
		self.emit(SIGNAL("clear"))
	def updatemodels(self, modelname):
		self.emit(SIGNAL("updatemodels"), modelname)
#	def model(self, text):
#		self.emit(SIGNAL("model"), text)
#	def generatevisualized(self, crops):
#		self.emit(SIGNAL("generatevisualized"), crops)

class countyFinder(QThread):
	def __init__(self, point):
		QThread.__init__(self)

		self.point = point

	def __del__(self):
		self.wait()

	def run(self):
		point = self.point
		print "CLICKED", point
		x, y = point
		url = "http://geoserver.rcac.purdue.edu:8081/geoserver/wfs?request=GetFeature&version=1.0.0&typeName=gabbs:gadm28&FILTER=%3CFilter%20xmlns=%22http://www.opengis.net/ogc%22%20xmlns:gml=%22http://www.opengis.net/gml%22%3E%3CContains%3E%3CPropertyName%3Ethe_geom%3C/PropertyName%3E%3Cgml:Point%20srsName=%22EPSG:3857%22%3E%3Cgml:coordinates%3E" + str(x) + "," + str(y) + "%3C/gml:coordinates%3E%3C/gml:Point%3E%3C/Contains%3E%3C/Filter%3E"
		file = urllib2.urlopen(url)
		print "FOUND"

		root = ET.parse(file).getroot()
		file.close()
		featurelist = root.findall("gml:featureMember", root.nsmap)
		if len(featurelist) == 0:
			self.findcounty(["Unknown", "Unknown", "Unknown"])
			return
		feature = featurelist[0]
		gadm = feature.find("gabbs:gadm28", root.nsmap)
		data = [gadm.find("gabbs:NAME_0", root.nsmap).text, gadm.find("gabbs:NAME_1", root.nsmap).text, gadm.find("gabbs:NAME_2", root.nsmap).text]
		self.findcounty(data)

	def findcounty(self, data):
		self.emit(SIGNAL("findcounty"), data)

def outputpath(workingdir, modelname, filename=None):
	path = "%s/output/%s" % (workingdir, modelname)
	if filename != None:
		path = path + "/" + filename
	return path

def findGDALCoordinates(path):
	if not os.path.isfile(path):
		return []
	data = gdal.Open(path,GA_ReadOnly)
	if data is None:
		return []
	geoTransform = data.GetGeoTransform()
	minx = geoTransform[0]
	maxy = geoTransform[3]
	maxx = minx + geoTransform[1]*data.RasterXSize
	miny = maxy + geoTransform[5]*data.RasterYSize

	sizex, sizey = data.RasterXSize, data.RasterYSize

	return minx,miny,maxx,maxy,sizex,sizey

def cropraster(source, target, bounds):
	minx,miny,maxx,maxy,sizex,sizey = findGDALCoordinates(source)

	px, py = (maxx - minx) / sizex, (maxy - miny) / sizey

	newbounds = [(bounds[0] - minx) / px, (bounds[1] - miny) / py, (bounds[2] - minx) / px, (bounds[3] - miny) / py]

	x, y, xs, ys = int(newbounds[0]), int(sizey - newbounds[3]), int(math.ceil(newbounds[2]-newbounds[0])), int(math.ceil(newbounds[3]-newbounds[1]))

	p = subprocess.Popen(["gdal_translate", "-srcwin", str(x), str(y), str(xs), str(ys), source, target])
	p.wait()

def getnewcrop(source, bounds):
	minx,miny,maxx,maxy,sizex,sizey = findGDALCoordinates(source)

	px, py = (maxx - minx) / sizex, (maxy - miny) / sizey

	newbounds = [(bounds[0] - minx) / px, (bounds[1] - miny) / py, (bounds[2] - minx) / px, (bounds[3] - miny) / py]

	x, y, xs, ys = int(newbounds[0]), int(sizey - newbounds[3]), int(math.ceil(newbounds[2]-newbounds[0])), int(math.ceil(newbounds[3]-newbounds[1]))

	return x, y, xs, ys, minx, miny, maxx, maxy, px, py, sizex, sizey

def aligntopleft (x1, minx1, px1, x2, minx2, px2): # Move bound by 1 pixel to adjust for 1-off error if necessary
	posx1 = [[x1, minx1 + px1 * x1], [x1+1, minx1 + px1 * (x1+1)]]
	posx2 = [[x2, minx2 + px2 * x2], [x2+1, minx2 + px2 * (x2+1)]]

	newx = min(list(itertools.product(posx1, posx2)), key= lambda x: abs(x[0][1] - x[1][1]))
	return newx[0][0], newx[1][0]

def docroppx(source, dest, x, y, xs, ys):
	p = subprocess.Popen(["gdal_translate", "-srcwin", str(x), str(y), str(xs), str(ys), source, dest])
	p.wait()

def rasterdiff(source, source2):
	if os.path.exists("1tmp.tif"):
		os.remove("1tmp.tif")
	if os.path.exists("2tmp.tif"):
		os.remove("2tmp.tif")
	if os.path.exists("diff.tif"):
		os.remove("diff.tif")

	extents1 = findGDALCoordinates(source)
	extents2 = findGDALCoordinates(source2)

	bounds = [max(extents1[0], extents2[0]), max(extents1[1], extents2[1]), min(extents1[2], extents2[2]), min(extents1[3], extents2[3])]

	x1, y1, xs1, ys1, minx1, miny1, maxx1, maxy1, px1, py1, sizex1, sizey1 = getnewcrop(source, bounds)
	x2, y2, xs2, ys2, minx2, miny2, maxx2, maxy2, px2, py2, sizex2, sizey2 = getnewcrop(source2, bounds)

	x1, x2 = aligntopleft(x1, minx1, px1, x2, minx2, px2)
	y1, y2 = aligntopleft(y1, maxy1, -py1, y2, maxy2, -py2)

	xs, ys = min(xs1, xs2), min(ys1, ys2)

	if xs > sizex1 - x1: xs = sizex1 - x1
	if ys > sizey1 - y1: ys = sizey1 - y1
	if xs > sizex2 - x2: xs = sizex2 - x2
	if ys > sizey2 - y2: ys = sizey2 - y2

	docroppx(source, "1tmp.tif", x1, y1, xs, ys)
	docroppx(source2, "2tmp.tif", x2, y2, xs, ys)

	p = subprocess.Popen(["gdal_calc.py", "-A", "1tmp.tif", "-B", "2tmp.tif", "--outfile=diff.tif",
	#"--calc=B-A", "--NoDataValue=-1"])
	"--NoDataValue=-5",
	"--calc=(B-A)*numpy.logical_and(A != -1, B != -1) - 2*numpy.logical_and(A == -1, B == -1) - numpy.logical_or(A == -1, B == -1)"])
	p.wait()

if __name__ == "__main__":
	import sys
	# create QT application
	app = QtGui.QApplication(sys.argv)
	# Initialize gabbs maps libraries
	gabbs.maps.gbsLoadLibrary()

	TabWidget = QtGui.QTabWidget()
	ui = Ui_TabWidget()
	ui.setupUi(TabWidget)
	TabWidget.show()

	sys.exit(app.exec_())
	# Exit gabbas maps libraries
	gabbs.maps.gbsUnloadLibrary()
