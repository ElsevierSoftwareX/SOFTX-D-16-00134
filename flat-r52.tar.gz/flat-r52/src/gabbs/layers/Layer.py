# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------
"""
Layer.py  -  base layer for gabbs maps
---------------------
date                 : August 2015
copyright            : (C) 2015 by Wei Wan
email                : wanw at purdue dot edu
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""
from os.path import isfile
from PyQt4.QtGui import QAction, QIcon
from qgis.gui import *
from gabbs.layers.LayerProperty import *
from gabbs.MapUtils import iface, debug_trace

class Layer(object):
    """Base class for layers"""
    layerName = None
    """Layer type name in menu"""
    layerIcon = None
    """Group icon in menu"""
    layerTypeName = None
    """Layer type identificator used to store in project"""
    layerTypeId = None
    """Numerical ID used in versions < 2.3"""
    layerId = None
    """Store 2 qgis objects"""
    layer = None
    layerAction = None

    layerAttribution = None

    def __init__(self):
        object.__init__(self)

    def getLayer(self):
        return self.layer

    def getLayerId(self):
        return self.layerId

    def setAddLayerCallback(self, addLayerCallback):
        """Set post processing in add layer method in canvas class
        """
        self.addLayerCallback = addLayerCallback

    def loadStyleFile(self, symPath):
        if isfile(symPath):
            res = self.layer.loadNamedStyle(symPath)
            if res[1]:
                return True
            else:
                return False
        else:
            return False