# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------
"""
ShapeViewer.py  -  example program to show layers and maps
---------------------
date                 : August 2015
copyright            : (C) 2015 by Wei Wan
email                : wanw at purdue dot edu
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""
#from PyQt4.QtCore import *
from PyQt4.QtGui import QColor
from qgis.core import *
from qgis.gui import *

class ReturnCode:
    SUCCESS = "SUCCESS"
    CREATE_LAYER_ERROR = "CREATE_LAYER_ERROR"
    ADD_LAYER_ERROR = "ADD_LAYER_ERROR"

class iface:
    '''Global class for interface to hold mapCanvas'''
    # Gui
    mainWindow = None
    mapCanvas = None
    mapContainer = None
    mapOverview = None
    mapToolBar = None
    mapLegend = None
    # Map zoom and cneter
    mapZoomScale = None
    mapCenterPoint = None

    @classmethod
    def getMainWindow(cls):
        return cls.mainWindow

    @classmethod
    def getMapCanvas(cls):
        return cls.mapCanvas

    @classmethod
    def legendInterface(cls):
        return cls.mapLegend

    @classmethod
    def addToolBarIcon(cls, action):
        cls.mapToolBar.addAction(action)

    @classmethod
    def removeToolBarIcon(cls, action):
        cls.mapToolBar.removeAction(action)

    @classmethod
    def addDockWidget(cls, dockWidgetArea, dockwidget):
        cls.mainWindow.addDockWidget(dockWidgetArea, dockwidget)

    @classmethod
    def removeDockWidget(cls, dockwidget):
        cls.mainWindow.removeDockWidget(dockwidget)

def debug_trace():
    '''set a tracepoint in the Python Debugger that works with Qt'''
    from PyQt4.QtCore import pyqtRemoveInputHook
    from pdb import set_trace
    pyqtRemoveInputHook()
    set_trace()