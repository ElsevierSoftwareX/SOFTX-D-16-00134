import os
import sys
import re
import subprocess
import time
import shutil

class FLAT:
    def __init__(self, working_dir = '.'):
        self.working_dir = os.path.expanduser(working_dir)


    def generate_map(self, result_file, outputpath, modelname, prefix, crop_list, outputfunction):
        print "GENERATE MAP"
        output = ''
        if os.path.isfile(result_file):
            for crop in crop_list:
                cmd = 'cd %s; /apps/share64/debian7/R/3.1.1/bin/Rscript dattotiff.R %s %s'%(self.working_dir, crop, result_file)
                print cmd
                #p = subprocess.Popen([cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                p = subprocess.Popen([cmd], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
#                output_msg, errors = p.communicate()
#                print output_msg
#                print errors
                output_msg = ""
                while True:
                        line = p.stdout.readline()
                        if not line: break
                        output_msg += line
                        if line.endswith("\n"): line = line[:-1]
                        print line
                        outputfunction(line)
                output += output_msg

                if os.path.exists("%s/out-%s.tif" % (self.working_dir, crop)):
                        shutil.move("%s/out-%s.tif" % (self.working_dir, crop), outputpath(self.working_dir, modelname, prefix+crop+".tif"))
                else:
                        print "ERROR: doesn't exist!", "%s/out-%s.tif" % (self.working_dir, crop)
        return output



    def run(self,input_file, input_file_proj, grid_siz, ndep, nidep, use_user_gams, outputfunction):
        print "RUNNING"
        outputfunction('Starting...')
        outputfunction('Running RForFLAT.R...')
        Rpath = '%s/RforFLAT.R'%(self.working_dir)
        cmd = 'cd %s; rm -f *.dat *.tif cropnames.csv; /apps/share64/debian7/R/3.1.1/bin/Rscript %s %s %s %s %s %s'%(self.working_dir, Rpath, input_file, input_file_proj, grid_siz, ndep, nidep)
        print cmd
        p = subprocess.Popen([cmd], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
#        outR, errorsR = p.communicate()
        outR = ""
        while True:
            line = p.stdout.readline()
            if not line: break
            outR += line
            if line.endswith("\n"): line = line[:-1]
            print line
            outputfunction(line)
        msg = '\n=====DEBUG INFO=====\n'
        msg = msg + '[RForFLAT.R]\n' + outR + '\n'
        if outR.find('Execution halted') != -1:
            msg = 'Failed\n\n' + msg
            outputfunction(msg)
            outputG = 'Not Executed'
            return

        print "RUNNING GAMS"
        outputfunction('Running GAMS program...')
        outputfunction(msg)
        if use_user_gams:
            cmd = 'cd %s;  /apps/share64/debian7/gams/gams-24.2.1/gams24.2_linux_x64_64_sfx/gams USERMODEL lo=2'%(self.working_dir)
        else:
            cmd = 'cd %s;  /apps/share64/debian7/gams/gams-24.2.1/gams24.2_linux_x64_64_sfx/gams FLAT lo=2'%(self.working_dir)
        print cmd
        if os.path.exists('%s/FLAT.log'%self.working_dir):
            os.remove('%s/FLAT.log'%self.working_dir)
        p = subprocess.Popen([cmd], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
#        outputG, errorsG = p.communicate()
        outputG = ""
        filepath = '%s/FLAT.log'%self.working_dir
        logfile = None
        while True:
                if os.path.exists(filepath):
                        logfile = open('%s/FLAT.log'%self.working_dir,'r')
                        break
                else:
                        if p.poll() != None: #application has finished
                                break
                        time.sleep(1)
        if logfile != None:
                while True:
                        where = logfile.tell()
                        line = logfile.readline()
                        if not line:
                                if p.poll() != None: #application has finished
                                        break
                                time.sleep(1)
                                logfile.seek(where)
                        else:
                            outputG += line
                            if line.endswith("\n"): line = line[:-1]
                            print line
                            outputfunction(line)

#                            if "Job" in line and "Stop" in line:
#                                    break
                logfile.close()

        """
        while True:
            line = p.stdout.readline()
            if not line: break
            outputG += line
            if line.endswith("\n"): line = line[:-1]
            print line
            outputfunction(line)
        if os.path.exists('%s/FLAT.log'%self.working_dir):
            with open('%s/FLAT.log'%self.working_dir,'r') as f:
                outputG = f.read()
        """
        #return (outputR, errorsR, outputG, errorsG)
        return (outR, outputG)

    def change_result_file_name(self, outputpath, modelname):
        newpath = outputpath(self.working_dir, modelname)
        if os.path.exists(newpath):
                shutil.rmtree(newpath)
        os.makedirs(newpath)

        print '%s/estimates.dat'%self.working_dir
        if os.path.isfile('%s/estimates.dat'%self.working_dir):
            shutil.move("%s/estimates.dat"%(self.working_dir), outputpath(self.working_dir, modelname, "estimates.dat"))
        if os.path.isfile('%s/covariances.dat'%self.working_dir):
            shutil.move("%s/covariances.dat"%(self.working_dir), outputpath(self.working_dir, modelname, "covariances.dat"))
        if os.path.isfile('%s/finalresults.dat'%self.working_dir):
            shutil.move("%s/finalresults.dat"%(self.working_dir), outputpath(self.working_dir, modelname, "finalresults.dat"))
        if os.path.isfile('%s/projectionresults.dat'%self.working_dir):
            shutil.move("%s/projectionresults.dat"%(self.working_dir), outputpath(self.working_dir, modelname, "projectionresults.dat"))
