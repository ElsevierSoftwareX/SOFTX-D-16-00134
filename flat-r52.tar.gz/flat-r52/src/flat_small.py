# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'flat-guiq.ui'
#
# Created: Mon Feb 22 02:00:34 2016
#      by: PyQt4 UI code generator 4.9.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from PyQt4.QtGui import *
from PyQt4.QtCore import *
import subprocess 
import os
import sys
import re
from flat_proxy import *
from util import *
import gabbs.maps
from qgis.core import *
from qgis.gui import *
from PyQt4.QtGui import *
from gabbs.MapUtils import iface


FLAT_DIR = os.path.expanduser('~/.flat')

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_TabWidget():
    def setupUi(self, TabWidget):
        TabWidget.setObjectName(_fromUtf8("TabWidget"))
        TabWidget.resize(679, 489)
        #TabWidget.resize(800, 560)
        self.tab1 = QtGui.QWidget()
        self.tab1.setObjectName(_fromUtf8("tab1"))
        self.layoutWidget = QtGui.QWidget(self.tab1)
        self.layoutWidget.setGeometry(QtCore.QRect(0, 0, 2, 2))
        self.layoutWidget.setObjectName(_fromUtf8("layoutWidget"))
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.layoutWidget)
        self.verticalLayout_3.setMargin(0)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.layoutWidget1 = QtGui.QWidget(self.tab1)
        self.layoutWidget1.setGeometry(QtCore.QRect(0, 0, 2, 2))
        self.layoutWidget1.setObjectName(_fromUtf8("layoutWidget1"))
        self.verticalLayout_4 = QtGui.QVBoxLayout(self.layoutWidget1)
        self.verticalLayout_4.setMargin(0)
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        self.layoutWidget2 = QtGui.QWidget(self.tab1)
        self.layoutWidget2.setGeometry(QtCore.QRect(10, 10, 661, 431))
        self.layoutWidget2.setObjectName(_fromUtf8("layoutWidget2"))
        self.verticalLayout_6 = QtGui.QVBoxLayout(self.layoutWidget2)
        self.verticalLayout_6.setMargin(0)
        self.verticalLayout_6.setObjectName(_fromUtf8("verticalLayout_6"))
        self.horizontalLayout_8 = QtGui.QHBoxLayout()
        self.horizontalLayout_8.setObjectName(_fromUtf8("horizontalLayout_8"))
        self.groupBox = QtGui.QGroupBox(self.layoutWidget2)
        self.groupBox.setAutoFillBackground(False)
        self.groupBox.setFlat(False)
        self.groupBox.setCheckable(False)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.groupBox)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout.addWidget(self.label)
        self.lineEdit_ModelName = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_ModelName.setObjectName(_fromUtf8("lineEdit_ModelName"))
        self.horizontalLayout.addWidget(self.lineEdit_ModelName)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.horizontalLayout_2.addWidget(self.label_2)
        self.comboBox_dataset = QtGui.QComboBox(self.groupBox)
        self.comboBox_dataset.setObjectName(_fromUtf8("comboBox_dataset"))
        self.horizontalLayout_2.addWidget(self.comboBox_dataset)
        self.verticalLayout_2.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.label_3 = QtGui.QLabel(self.groupBox)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.horizontalLayout_3.addWidget(self.label_3)
        self.comboBox_GridSize = QtGui.QComboBox(self.groupBox)
        self.comboBox_GridSize.setObjectName(_fromUtf8("comboBox_GridSize"))
        self.horizontalLayout_3.addWidget(self.comboBox_GridSize)
        self.verticalLayout_2.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_7 = QtGui.QHBoxLayout()
        self.horizontalLayout_7.setObjectName(_fromUtf8("horizontalLayout_7"))
        self.label_6 = QtGui.QLabel(self.groupBox)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.horizontalLayout_7.addWidget(self.label_6)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
        self.label_4 = QtGui.QLabel(self.groupBox)
        self.label_4.setFrameShape(QtGui.QFrame.Box)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.horizontalLayout_4.addWidget(self.label_4)
        self.comboBox_NumDepVars = QtGui.QComboBox(self.groupBox)
        self.comboBox_NumDepVars.setObjectName(_fromUtf8("comboBox_NumDepVars"))
        self.horizontalLayout_4.addWidget(self.comboBox_NumDepVars)
        self.verticalLayout.addLayout(self.horizontalLayout_4)
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName(_fromUtf8("horizontalLayout_5"))
        self.label_5 = QtGui.QLabel(self.groupBox)
        self.label_5.setFrameShape(QtGui.QFrame.Box)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.horizontalLayout_5.addWidget(self.label_5)
        self.comboBox_NumNDepVars = QtGui.QComboBox(self.groupBox)
        self.comboBox_NumNDepVars.setObjectName(_fromUtf8("comboBox_NumNDepVars"))
        self.horizontalLayout_5.addWidget(self.comboBox_NumNDepVars)
        self.verticalLayout.addLayout(self.horizontalLayout_5)
        self.horizontalLayout_7.addLayout(self.verticalLayout)
        self.verticalLayout_2.addLayout(self.horizontalLayout_7)
        self.horizontalLayout_6 = QtGui.QHBoxLayout()
        self.horizontalLayout_6.setObjectName(_fromUtf8("horizontalLayout_6"))
        self.label_7 = QtGui.QLabel(self.groupBox)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.horizontalLayout_6.addWidget(self.label_7)
        self.comboBox_ChooseModel = QtGui.QComboBox(self.groupBox)
        self.comboBox_ChooseModel.setObjectName(_fromUtf8("comboBox_ChooseModel"))
        self.horizontalLayout_6.addWidget(self.comboBox_ChooseModel)
        self.verticalLayout_2.addLayout(self.horizontalLayout_6)
        self.horizontalLayout_8.addWidget(self.groupBox)
        self.verticalLayout_5 = QtGui.QVBoxLayout()
        self.verticalLayout_5.setObjectName(_fromUtf8("verticalLayout_5"))
        self.groupBox_2 = QtGui.QGroupBox(self.layoutWidget2)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.textBrowser_Instruction = QtGui.QTextBrowser(self.groupBox_2)
        self.textBrowser_Instruction.setGeometry(QtCore.QRect(5, 30, 141, 131))
        self.textBrowser_Instruction.setObjectName(_fromUtf8("textBrowser_Instruction"))
        self.verticalLayout_5.addWidget(self.groupBox_2)
        self.pushButton_RunFLAT = QtGui.QPushButton(self.layoutWidget2)
        self.pushButton_RunFLAT.setObjectName(_fromUtf8("pushButton_RunFLAT"))
        self.verticalLayout_5.addWidget(self.pushButton_RunFLAT)
        self.horizontalLayout_8.addLayout(self.verticalLayout_5)
        self.verticalLayout_6.addLayout(self.horizontalLayout_8)
        self.groupBox_3 = QtGui.QGroupBox(self.layoutWidget2)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.textEdit_Log = QtGui.QTextEdit(self.groupBox_3)
        self.textEdit_Log.setGeometry(QtCore.QRect(10, 30, 641, 171))
        self.textEdit_Log.setObjectName(_fromUtf8("textEdit_Log"))
        self.verticalLayout_6.addWidget(self.groupBox_3)
        TabWidget.addTab(self.tab1, _fromUtf8(""))
        self.tab2 = QtGui.QWidget()
        self.tab2.setObjectName(_fromUtf8("tab2"))
        self.verticalLayout_7 = QtGui.QVBoxLayout(self.tab2)
        self.verticalLayout_7.setObjectName(_fromUtf8("verticalLayout_7"))
        self.horizontalLayout_13 = QtGui.QHBoxLayout()
        self.horizontalLayout_13.setObjectName(_fromUtf8("horizontalLayout_13"))
        self.verticalLayout_7.addLayout(self.horizontalLayout_13)
        self.horizontalLayout_9 = QtGui.QHBoxLayout()
        self.horizontalLayout_9.setObjectName(_fromUtf8("horizontalLayout_9"))
        self.verticalLayout_7.addLayout(self.horizontalLayout_9)
        self.label_8 = QtGui.QLabel(self.tab2)
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.label_8.setFont(font)
        self.label_8.setObjectName(_fromUtf8("label_8"))
        self.verticalLayout_7.addWidget(self.label_8)
        self.label_9 = QtGui.QLabel(self.tab2)
        self.label_9.setObjectName(_fromUtf8("label_9"))
        self.verticalLayout_7.addWidget(self.label_9)
        self.horizontalLayout_14 = QtGui.QHBoxLayout()
        self.horizontalLayout_14.setObjectName(_fromUtf8("horizontalLayout_14"))
        self.scrollArea = QtGui.QScrollArea(self.tab2)
        self.scrollArea.setAutoFillBackground(True)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName(_fromUtf8("scrollArea"))
        self.scrollAreaWidgetContents = QtGui.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 561, 253))
        self.scrollAreaWidgetContents.setObjectName(_fromUtf8("scrollAreaWidgetContents"))
        self.textEdit_ModelRes = QtGui.QTextEdit(self.scrollAreaWidgetContents)
        self.textEdit_ModelRes.setGeometry(QtCore.QRect(0, 0, 575, 297))
        self.textEdit_ModelRes.setAutoFillBackground(True)
        self.textEdit_ModelRes.setObjectName(_fromUtf8("textEdit_ModelRes"))
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.horizontalLayout_14.addWidget(self.scrollArea)
        self.pushButton_DownloadMD = QtGui.QPushButton(self.tab2)
        self.pushButton_DownloadMD.setObjectName(_fromUtf8("pushButton_DownloadMD"))
        self.horizontalLayout_14.addWidget(self.pushButton_DownloadMD)
        self.verticalLayout_7.addLayout(self.horizontalLayout_14)
        self.horizontalLayout_10 = QtGui.QHBoxLayout()
        self.horizontalLayout_10.setObjectName(_fromUtf8("horizontalLayout_10"))
        self.label_10 = QtGui.QLabel(self.tab2)
        self.label_10.setObjectName(_fromUtf8("label_10"))
        self.horizontalLayout_10.addWidget(self.label_10)
        self.pushButton_DownloadPD = QtGui.QPushButton(self.tab2)
        self.pushButton_DownloadPD.setObjectName(_fromUtf8("pushButton_DownloadPD"))
        self.horizontalLayout_10.addWidget(self.pushButton_DownloadPD)
        self.verticalLayout_7.addLayout(self.horizontalLayout_10)
        self.horizontalLayout_11 = QtGui.QHBoxLayout()
        self.horizontalLayout_11.setObjectName(_fromUtf8("horizontalLayout_11"))
        self.label_11 = QtGui.QLabel(self.tab2)
        self.label_11.setObjectName(_fromUtf8("label_11"))
        self.horizontalLayout_11.addWidget(self.label_11)
        self.pushButton_DownloadCM = QtGui.QPushButton(self.tab2)
        self.pushButton_DownloadCM.setObjectName(_fromUtf8("pushButton_DownloadCM"))
        self.horizontalLayout_11.addWidget(self.pushButton_DownloadCM)
        self.verticalLayout_7.addLayout(self.horizontalLayout_11)
        self.horizontalLayout_12 = QtGui.QHBoxLayout()
        self.horizontalLayout_12.setObjectName(_fromUtf8("horizontalLayout_12"))
        self.label_12 = QtGui.QLabel(self.tab2)
        self.label_12.setObjectName(_fromUtf8("label_12"))
        self.horizontalLayout_12.addWidget(self.label_12)
        self.pushButton_DownloadInstructions = QtGui.QPushButton(self.tab2)
        self.pushButton_DownloadInstructions.setObjectName(_fromUtf8("pushButton_DownloadInstructions"))
        self.horizontalLayout_12.addWidget(self.pushButton_DownloadInstructions)
        self.verticalLayout_7.addLayout(self.horizontalLayout_12)
        TabWidget.addTab(self.tab2, _fromUtf8(""))
        self.tab3 = QtGui.QWidget()
        self.tab3.setObjectName(_fromUtf8("tab3"))
        self.label_15 = QtGui.QLabel(self.tab3)
        self.label_15.setGeometry(QtCore.QRect(210, 0, 81, 31))
        self.label_15.setObjectName(_fromUtf8("label_15"))
        self.comboBox_PicType = QtGui.QComboBox(self.tab3)
        self.comboBox_PicType.setGeometry(QtCore.QRect(240, 420, 121, 27))
        self.comboBox_PicType.setObjectName(_fromUtf8("comboBox_PicType"))
        self.layoutWidget3 = QtGui.QWidget(self.tab3)
        self.layoutWidget3.setGeometry(QtCore.QRect(10, 10, 149, 441))
        self.layoutWidget3.setObjectName(_fromUtf8("layoutWidget3"))
        self.gridLayout = QtGui.QGridLayout(self.layoutWidget3)
        self.gridLayout.setMargin(0)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_14 = QtGui.QLabel(self.layoutWidget3)
        self.label_14.setObjectName(_fromUtf8("label_14"))
        self.gridLayout.addWidget(self.label_14, 3, 0, 1, 1)
        self.label_13 = QtGui.QLabel(self.layoutWidget3)
        self.label_13.setObjectName(_fromUtf8("label_13"))
        self.gridLayout.addWidget(self.label_13, 0, 0, 1, 1)
        self.label_16 = QtGui.QLabel(self.layoutWidget3)
        self.label_16.setObjectName(_fromUtf8("label_16"))
        self.gridLayout.addWidget(self.label_16, 4, 0, 1, 1)
        self.pushButton_GenNewMap = QtGui.QPushButton(self.layoutWidget3)
        self.pushButton_GenNewMap.setObjectName(_fromUtf8("pushButton_GenNewMap"))
        self.gridLayout.addWidget(self.pushButton_GenNewMap, 5, 0, 1, 1)
        self.comboBox_DepVarMap = QtGui.QComboBox(self.layoutWidget3)
        self.comboBox_DepVarMap.setObjectName(_fromUtf8("comboBox_DepVarMap"))
        self.gridLayout.addWidget(self.comboBox_DepVarMap, 1, 0, 1, 1)
        self.pushButton_SaveMap = QtGui.QPushButton(self.tab3)
        self.pushButton_SaveMap.setGeometry(QtCore.QRect(450, 420, 98, 27))
        self.pushButton_SaveMap.setObjectName(_fromUtf8("pushButton_SaveMap"))
        self.widget_Map = QtGui.QWidget(self.tab3)
        #self.widget_Map.setGeometry(QtCore.QRect(180, 30, 471, 361))
        self.widget_Map.setGeometry(QtCore.QRect(170, 20, 511, 401))
        self.widget_Map.setObjectName(_fromUtf8("widget_Map"))
        #self.layout_Map = QtGui.QVBoxLayout(self.tab3)
        #self.layout_Map.setGeometry(QtCore.QRect(180, 30, 471, 361))
        #self.layout_Map.setObjectName(_fromUtf8("layout_Map"))
        TabWidget.addTab(self.tab3, _fromUtf8(""))

        self.retranslateUi(TabWidget)
        TabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(TabWidget)

        #zsd-add some items in combo
        self.comboBox_dataset.addItems(['Default Maize Dataset','Default Multi-crop Dataset','Upload Dataset'])
        self.comboBox_GridSize.addItems(['%d by %d'%(i,i) for i in range(1,61)])
        self.comboBox_NumDepVars.addItems(['%d'%i for i in range(1,11)])
        self.comboBox_NumNDepVars.addItems(['%d'%i for i in range(1,51)])
        self.comboBox_ChooseModel.addItems(['Default (see Instruction to download model)', 'Upload User Defined Model'])
        self.comboBox_PicType.addItems(['PNG','JPG'])
        self.lineEdit_ModelName.setText('Enter_new_job_name_here...')
        self.textBrowser_Instruction.setHtml('Click <a href="#anchor">here</a> to download dataset sample and descriptions on building your own dataset') 
        #zsd--add signal or slots
        self.pushButton_RunFLAT.clicked.connect(self.RunFLAT)
        self.pushButton_GenNewMap.clicked.connect(self.generateMap)
        self.pushButton_SaveMap.clicked.connect(self.saveCurrentMap)
        self.comboBox_dataset.currentIndexChanged.connect(self.SelectData)
        self.comboBox_ChooseModel.currentIndexChanged.connect(self.SelectModel)
        self.comboBox_DepVarMap.currentIndexChanged.connect(self.ChangeCrop)
        self.pushButton_DownloadMD.clicked.connect(self.download_estimate)
        self.pushButton_DownloadPD.clicked.connect(self.download_final)
        self.pushButton_DownloadCM.clicked.connect(self.download_covariance)
        self.textBrowser_Instruction.anchorClicked.connect(self.download_datasample)
        self.pushButton_DownloadInstructions.clicked.connect(self.download_instructions)
        #zsd--add map object
        self.gridlayout_Map = QtGui.QGridLayout(self.widget_Map)
        self.gridlayout_Map.setObjectName(_fromUtf8('gridlayout_Map'))
        self.frame_Map = QtGui.QFrame(self.widget_Map)
        self.frame_Map.setFrameShape(QtGui.QFrame.StyledPanel)
        self.frame_Map.setFrameShadow(QtGui.QFrame.Raised)
        self.frame_Map.setObjectName(_fromUtf8("frame_Map"))
        self.gridlayout_Map.addWidget(self.frame_Map, 0, 0, 1, 1)
        self.layout_Map = QtGui.QVBoxLayout(self.frame_Map)

        #create working directory & put a few staffs in the working directory
        self.SetupRunningDir()
        self.raster_crop = None
        self.use_user_gams = False
        
        # Create a Map Container, aka map canvas
        canvasProp = {'panControl':  True,
                      'panControlOptions': 
                                   {'style':'DEFAULT'},
                      'zoomControl': True,
                      'zoomControlOptions': 
                                   {'size': 'CUSTOM',
                                    'option': 'ZOOMIN, ZOOMOUT, ZOOMHOME'},
                      'selectControl': True,
                      'selectControlOptions': 
                                   {'size': 'CUSTOM',
                                    'option': 'SINGLE, RECTANGLE, POLYGON, FREEHAND, RADIUS'},
                      'layerControl':  True,
                      # 'mapTipControl':True,
                      'pluginControl':'drawingtool',
                      'captureControl': True}

        self.mapContainer = gabbs.maps.MapContainer(canvasProp)
        # Add canvas as a widget to the layout
        self.layout_Map.addWidget(self.mapContainer)
    
        #-85.508742, 46.120850
        #<lon>-86.9080556</lon><lat>40.4258333</lat>
        # Create a Map object
        mapProp = {'center':
                #{'lon': -86.208742,
                      {'lon': -16.208742,
                          #'lat': 39.820850},
                       'lat': 1.820850},
                   'zoom':    1,
                   'maxZoom': 18,
                   'minZoom': 1,
                   'mapTypeId': 'OSM'} #OSM #'GOOGLE_HYBRID'}
        self.map = gabbs.maps.Map(mapProp)
        self.mapContainer.addLayer(self.map)

        #color legend
        self.colorBarFrame = QFrame(iface.mapCanvas)
        self.colorBarFrame.setGeometry(QRect(4, 5, 476, 31))
        self.colorBarFrame.setObjectName(_fromUtf8("colorBarFrame"))

        self.colorBars = []
        self.color1 = QWidget(self.colorBarFrame)
        self.color1.setGeometry(QRect(20, 5, 44, 21))
        self.color1.setStyleSheet(_fromUtf8("background-color: #ccffff;"))
        self.color1.setObjectName(_fromUtf8("color1"))
        self.color2 = QWidget(self.colorBarFrame)
        self.color2.setGeometry(QRect(64, 5, 44, 21))
        self.color2.setStyleSheet(_fromUtf8("background-color: #00ff80;"))
        self.color2.setObjectName(_fromUtf8("color2"))
        self.color3 = QWidget(self.colorBarFrame)
        self.color3.setGeometry(QRect(108, 5, 44, 21))
        self.color3.setStyleSheet(_fromUtf8("background-color: #80ff00;"))
        self.color3.setObjectName(_fromUtf8("color3"))
        self.color4 = QWidget(self.colorBarFrame)
        self.color4.setGeometry(QRect(152, 5, 44, 21))
        self.color4.setStyleSheet(_fromUtf8("background-color: #ffff00;"))
        self.color4.setObjectName(_fromUtf8("color4"))
        self.color5 = QWidget(self.colorBarFrame)
        self.color5.setGeometry(QRect(196, 5, 44, 21))
        self.color5.setStyleSheet(_fromUtf8("background-color: #ff8000;"))
        self.color5.setObjectName(_fromUtf8("color5"))
        self.color6 = QWidget(self.colorBarFrame)
        self.color6.setGeometry(QRect(240, 5, 44, 21))
        self.color6.setStyleSheet(_fromUtf8("background-color: #ff0000;"))
        self.color6.setObjectName(_fromUtf8("color6"))
        
        self.colorBars.append(self.color1)
        self.colorBars.append(self.color2)
        self.colorBars.append(self.color3)
        self.colorBars.append(self.color4)
        self.colorBars.append(self.color5)
        self.colorBars.append(self.color6)

        self.legendValues = []
        self.l0 = QLabel(self.colorBarFrame)
        self.l0.setGeometry(QRect(22+10, 7, 41, 16))
        self.l0.setObjectName(_fromUtf8("l0"))
        self.l1 = QLabel(self.colorBarFrame)
        self.l1.setGeometry(QRect(55+10, 7, 41, 16))
        self.l1.setObjectName(_fromUtf8("l1"))
        self.l2 = QLabel(self.colorBarFrame)
        self.l2.setGeometry(QRect(99+10, 7, 41, 16))
        self.l2.setObjectName(_fromUtf8("l2"))
        self.l3 = QLabel(self.colorBarFrame)
        self.l3.setGeometry(QRect(143+10, 7, 41, 16))
        self.l3.setObjectName(_fromUtf8("l3"))
        self.l4 = QLabel(self.colorBarFrame)
        self.l4.setGeometry(QRect(187+10, 7, 41, 16))
        self.l4.setObjectName(_fromUtf8("l4"))
        self.l5 = QLabel(self.colorBarFrame)
        self.l5.setGeometry(QRect(231+10, 7, 41, 16))
        self.l5.setObjectName(_fromUtf8("l5"))


        self.legendValues.append(self.l0)
        self.legendValues.append(self.l1)
        self.legendValues.append(self.l2)
        self.legendValues.append(self.l3)
        self.legendValues.append(self.l4)
        self.legendValues.append(self.l5)

        self.hideColorBarFrame()


        #Countries
        #temporarylly close those layers
        filePath = '%s/countries.xml'%FLAT_DIR
        rasterProp = {"layerName":     "Country",
                      "opacity": 0.5}
        rasterProp["fileName"] = filePath
        self.raster_country = gabbs.maps.Raster(rasterProp)
        self.mapContainer.addLayer(self.raster_country)

        '''
        file_path = '%s/country/ne_10m_admin_0_countries.shp'%FLAT_DIR
        polygonProp = {"layerName":     'Country',
                       "fileName":      file_path,
                       "opacity": 0.2,
                       'useSimpleStyle': True,
                       'color':'#808080'
                       }
        self.raster_country = gabbs.maps.Vector(polygonProp)
        self.mapContainer.addLayer(self.raster_country)
        '''


        #Provinces
        filePath = '%s/provinces.xml'%FLAT_DIR
        rasterProp = {"layerName":     "Province",
                      "opacity": 0.5}
        rasterProp["fileName"] = filePath
        self.raster_province = gabbs.maps.Raster(rasterProp)
        self.mapContainer.addLayer(self.raster_province)

        '''
        file_path = '%s/province/ne_10m_admin_1_states_provinces.shp'%FLAT_DIR
        polygonProp = {"layerName":     'Province',
                       "fileName":      file_path,
                       'opacity': 0.2,
                       'useSimpleStyle': True,
                       'color':'#808080'
                       }
        self.raster_province = gabbs.maps.Vector(polygonProp)
        self.mapContainer.addLayer(self.raster_province)
        '''

        #gadm28
        #temporarly disabled county
        '''
        filePath = '%s/gadm28.xml'%FLAT_DIR
        rasterProp = {"layerName":     "County",
                      "opacity":0.3}
        rasterProp["fileName"] = filePath
        self.raster_gadm28 = gabbs.maps.Raster(rasterProp)
        self.mapContainer.addLayer(self.raster_gadm28)
        '''

        

        '''
        filePath = '/home/mygeohub/zsdlightning/flat/out-maize.tif'
        rasterProp = {"layerName":     "soybean-2",
                "useCostumStyle": True, 
                "styleFileName": '/home/mygeohub/zsdlightning/flat/crop-color.qml'}
        rasterProp["fileName"] = filePath
        self.raster_crop2 = gabbs.maps.Raster(rasterProp)
        self.mapContainer.addLayer(self.raster_crop2)
        '''

 

        #crops = self.GenerateVisualized()
        #print crops

        '''
        uri = 'http://geoserver.rcac.purdue.edu:8081/geoserver/gabbs/wfs?srsname=EPSG:23030&typename=gabbs:gadm28&version=1.0.0&request=GetFeature&service=WFS'
        print uri
        self.vector_gadm28 = lambda: None
        setattr(self.vector_gadm28, 'layer',  QgsVectorLayer(uri, "gadm28", "WFS"))
        setattr(self.vector_gadm28, 'layerName', 'Gadm28')
        
        self.mapContainer.addLayer(self.vector_gadm28)
        '''


 


    #zsd -- self defined slot functions
    def clearLegendValues(self):
        for i in range(0,6):
            self.legendValues[i].setText(_translate("Widget", "", None))
        return

    def setLegendValues(self):
        vals = [0, 0.1, 0.2, 0.3, 0.4, 0.5]
        for i in range(0,6):
            #self.legendValues[i].setText(_translate('Widget', str(vals[i]), None)) 
            self.legendValues[i].setText(str(vals[i]))
            self.legendValues[i].setStyleSheet('color: black;')

        return

    def showColorBarFrame(self):
        for i in range(6):
            self.colorBars[i].show()
        self.colorBarFrame.show()

        return

    def hideColorBarFrame(self):
        self.colorBarFrame.hide()
        return


    def download_instructions(self):
        file_path = os.path.expanduser('%s/instructions.pdf'%(FLAT_DIR))
        if os.path.isfile(file_path):
            process_download(file_path)
        else:
            QtGui.QMessageBox.warning(self.tab1, "Error", "Does not have instruction documents.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)


    def download_datasample(self, argv1):
        file_path = os.path.expanduser('%s/SampleDataset.xlsx'%(FLAT_DIR))
        if os.path.isfile(file_path):
            process_download(file_path)
        else:
            QtGui.QMessageBox.warning(self.tab1, "Error", "Does not have data samples.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)


    def SelectData(self):
        dt = str(self.comboBox_dataset.currentText())
        if dt == 'Upload Dataset':
            user_data = '%s/userdata.csv'%FLAT_DIR
            process_upload(user_data)


    def SetCacheDir(self, wms_xml, cache_dir):
        replace_file(wms_xml, 'CACHEPATH', cache_dir)

    def SetupRunningDir(self):
        self.script_dir = os.path.dirname(sys.argv[0])
        if not os.path.exists(FLAT_DIR):
            os.mkdir(FLAT_DIR)
        else:
            os.system('rm -f %s/*'%(FLAT_DIR))
        os.system('cp -r %s %s'%(os.path.join(self.script_dir, "resource/*"), FLAT_DIR))
        os.system('cp %s %s'%(os.path.join(self.script_dir, "*.R"), FLAT_DIR))
        #set up WMS cache directory
        self.SetCacheDir('%s/provinces.xml'%FLAT_DIR, '%s/gdalwmscache'%FLAT_DIR)
        self.SetCacheDir('%s/countries.xml'%FLAT_DIR, '%s/gdalwmscache'%FLAT_DIR)
        self.SetCacheDir('%s/gadm28.xml'%FLAT_DIR, '%s/gdalwmscache'%FLAT_DIR)
        

    def ChangeCrop(self):
        crop = str(self.comboBox_DepVarMap.currentText())
        print 'current crop ', crop
        self.hideColorBarFrame()
        raster_path = os.path.expanduser(FLAT_DIR + '/out-%s.tif'%crop)
        if os.path.isfile(raster_path):
            if self.raster_crop:
                gabbs.maps.gbsRemoveLayer(self.raster_crop)
            
            rasterProp = {"layerName":     crop, 
                "useCostumStyle": True, 
                "styleFileName": os.path.expanduser('%s/crop-color.qml'%FLAT_DIR)}
            rasterProp["fileName"] = raster_path
            self.raster_crop = gabbs.maps.Raster(rasterProp)
            self.mapContainer.addLayer(self.raster_crop)
            self.map.canvas.refresh()
            self.setLegendValues()
            self.showColorBarFrame()
            #print self.mapContainer.canvas.setLayerSet
            #self.mapContainer.canvas.setLayerSet([QgsMapCanvasLayer(self.raster_crop.getLayer())])
            



    def SelectModel(self):
        md = str(self.comboBox_ChooseModel.currentText())
        if md == 'Upload User Defined Model':
            user_model = '%s/USERMODEL.gms'%FLAT_DIR
            process_upload(user_model)
            self.use_user_gams = True
        else:
            self.use_user_gams = False

    def download_estimate(self):
        model_name = self.lineEdit_ModelName.text()
        file_path = os.path.expanduser('%s/estimates_%s.dat'%(FLAT_DIR, model_name))
        if os.path.isfile(file_path):
            process_download(file_path)
        else:
            QtGui.QMessageBox.warning(self.tab2, "Error", "Does not have results.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)


            

    def download_covariance(self):
        model_name = self.lineEdit_ModelName.text()
        file_path = os.path.expanduser('%s/covariances_%s.dat'%(FLAT_DIR, model_name))
        if os.path.isfile(file_path):
            process_download(file_path)
        else:
            QtGui.QMessageBox.warning(self.tab2, "Error", "Does not have results.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)

    def download_final(self):
        model_name = self.lineEdit_ModelName.text()
        file_path = os.path.expanduser('%s/finalresults_%s.dat'%(FLAT_DIR, model_name))
        if os.path.isfile(file_path):
            process_download(file_path)
        else:
            QtGui.QMessageBox.warning(self.tab2, "Error", "Does not have results.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)

    #saved the current map
    def saveCurrentMap(self):
        #autmoatically remove the drawing bounding box
        gabbs.maps.gbsRemoveDrawingBounds()
        if app != None:
            app.processEvents()
        #save image
        image_type = str(self.comboBox_PicType.currentText()).lower()
        self.mapContainer.takeScreenshot_v2(os.path.expanduser(FLAT_DIR), image_type)
        '''
        image_type = 'png'
        tempPath = os.path.expanduser(FLAT_DIR)
        p = QPixmap.grabWindow(iface.mapCanvas.winId())
        p.save(tempPath + "/img." + image_type, image_type)

        # print "imageDownload1"
        call(["/usr/bin/exportfile", tempPath + "/img." + image_type])
        # print "done"
        '''




    #zoom to the bounding boxes selected by the user
    def generateMap(self):
        box = gabbs.maps.gbsGetDrawingBounds()
        if box:
            print box
        else:
            print 'No regision is selected'
            return
        # QgsRectangle
        lonFrom = gabbs.maps.gbsGetDrawingBounds().topLeft().x() 
        latFrom = gabbs.maps.gbsGetDrawingBounds().topLeft().y()
        lonTo = gabbs.maps.gbsGetDrawingBounds().bottomRight().x()
        latTo = gabbs.maps.gbsGetDrawingBounds().bottomRight().y()

        print lonFrom, latFrom, lonTo, latTo
        center_lon = (lonFrom + lonTo)/2
        center_lat = (latFrom + latTo)/2;
        print center_lon, center_lat
        crsTransform = self.map.createCrsTransform()
        centerPoint = crsTransform.transform(QgsPoint(center_lon, center_lat), QgsCoordinateTransform.ForwardTransform)
        topLeftPoint = crsTransform.transform(QgsPoint(lonFrom, latFrom), QgsCoordinateTransform.ForwardTransform)
        bottomRightPoint = crsTransform.transform(QgsPoint(lonTo, latTo), QgsCoordinateTransform.ForwardTransform)
        self.map.canvas.setCenter(centerPoint)
        self.map.mapCenterPoint = centerPoint
        rect = QgsRectangle(topLeftPoint, bottomRightPoint)
        self.map.canvas.setExtent(rect)
        self.map.canvas.refresh()

        return


    #read the results in FLAT_DIR and generate the .tif files and fill the variables in third Tab
    def GetCrops(self):
        crop_names = 'cropnames.csv'
        items = []
        with open(os.path.expanduser(FLAT_DIR + '/' + crop_names), 'r') as f:
            for line in f:
                items.append(line.strip()[1:-1])
        return items

    def GenerateVisualized(self, crops):
        self.comboBox_DepVarMap.clear()
        self.comboBox_DepVarMap.addItems(crops)
        return 
            


    def appendLogMessage(self, text):
        if str(self.textEdit_Log.toPlainText()) == "":
            self.textEdit_Log.document().setPlainText(str(text))
        else:
            self.textEdit_Log.document().setPlainText(str(self.textEdit_Log.toPlainText()) + "\n" + str(text))
            #self.textEdit_Log.moveCursor(QtGui.QTextCursor.End)
		# self.update()
        if app != None:
            app.processEvents()
        return



                
    def ClearPreviousCropFractionLayers(self):
        self.comboBox_DepVarMap.clear()
        self.hideColorBarFrame()
        if self.raster_crop:
            gabbs.maps.gbsRemoveLayer(self.raster_crop)
            self.raster_crop = None
        return

    def RunFLAT(self):
        model_name = str(self.lineEdit_ModelName.text())
        if model_name.find('Enter_new_job_name_here') != -1:
            QtGui.QMessageBox.warning(self.tab1, "Error", "Please specify your model name.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)
            return

        print 'I will run Rscript in the backend'
        #dataset chosed
        dt = str(self.comboBox_dataset.currentText())
        if dt == 'Default Maize Dataset':
            data_file = 'defaultmaizedataset.csv' 
        elif dt == 'Default Multi-crop Dataset':
            data_file = 'defaultmulticropdataset.csv'
        else:
            data_file = 'userdata.csv'
        #check whether input files exist
        if not os.path.isfile('%s/%s'%(FLAT_DIR, data_file)):
            QtGui.QMessageBox.warning(self.tab1, "Error", "Does not have input csv files, check program!", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)
        if self.use_user_gams and not os.path.isfile('%s/USERMODEL.gms'%FLAT_DIR) or not self.use_user_gams and not os.path.isfile('%s/FLAT.gms'%FLAT_DIR):
            QtGui.QMessageBox.warning(self.tab1, "Error", "Does not have input GAMS script, check program!", QtGui.QMessageBox.Ok, QtGui.QMessageBox.NoButton,QtGui.QMessageBox.NoButton)


        #selected Grid Size
        grid_siz = str(self.comboBox_GridSize.currentText())
        grid_siz = grid_siz.split(' ')[0]
        #No. of Dependent Variables
        ndep = str(self.comboBox_NumDepVars.currentText())
        #No. of InDependent Variables
        nidep = str(self.comboBox_NumNDepVars.currentText())
        #run FLAT
        self.textEdit_Log.clear()
        self.ClearPreviousCropFractionLayers()
        flat = FLAT(FLAT_DIR)
        outR,outG = flat.run('%s/%s'%(FLAT_DIR, data_file), grid_siz, ndep , nidep, self)
        #RForFlatR failed
        if outG.find('Not Executed') != -1:
            return
        else:
            self.textEdit_Log.clear()
            self.appendLogMessage('Starting...')
            self.appendLogMessage('Running RForFLAT.R...')
            self.appendLogMessage('Running GAMS program...')
            #Gams running failed
            if outG.find('Status: Normal completion') == -1:
                self.appendLogMessage('Failed')
                msg = '\n=====DEBUG INFO=====\n'
                msg = msg + '[RForFLAT.R]\n' + outR + '\n'
                msg = msg + '\n\n[GAMS]\n' + outG
                self.appendLogMessage(msg)
                return

        #load the results
        estimates = flat.get_estimate()
        print estimates
        if estimates:
            self.textEdit_ModelRes.setText(estimates)
        #change result file name to append model name as a suffix
        model_name = self.lineEdit_ModelName.text()
        flat.change_result_file_name(model_name)
        #fulfill the items in "dependent variables" in 3rd Tab
        crops = self.GetCrops()
        print crops
        self.appendLogMessage('Generating crop fraction layers...')
        msg = '\n\n=====DEBUG INFO=====\n'
        msg = msg + '[RForFLAT.R]\n' + outR + '\n'
        msg = msg + '\n\n[GAMS]\n' + outG
        self.appendLogMessage(msg)
        outC = flat.generate_map(model_name, crops)
        self.textEdit_Log.clear()
        self.appendLogMessage('Starting...')
        self.appendLogMessage('Running RForFLAT.R...')
        self.appendLogMessage('Running GAMS program...')
        self.appendLogMessage('Generating crop fraction layers...')
        self.appendLogMessage('Finished!')
        msg = '\n=====DEBUG INFO=====\n'
        msg = msg + '[RForFLAT.R]\n' + outR + '\n'
        msg = msg + '\n\n[GAMS]\n' + outG
        msg = msg + '\n\n[CropFraction]\n' + outC
        self.appendLogMessage(msg)
        self.GenerateVisualized(crops)


    def retranslateUi(self, TabWidget):
        TabWidget.setWindowTitle(QtGui.QApplication.translate("TabWidget", "FLAT in the Cloud", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("TabWidget", "Inputs", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("TabWidget", "Model Name", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("TabWidget", "Choose Dataset", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("TabWidget", "Choose Grid Size (lon/lat minute)", None, QtGui.QApplication.UnicodeUTF8))
        self.label_6.setText(QtGui.QApplication.translate("TabWidget", "Variables", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("TabWidget", "No. of Dependent Variables", None, QtGui.QApplication.UnicodeUTF8))
        self.label_5.setText(QtGui.QApplication.translate("TabWidget", "No. of Independent Variables", None, QtGui.QApplication.UnicodeUTF8))
        self.label_7.setText(QtGui.QApplication.translate("TabWidget", "Choose Model", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setTitle(QtGui.QApplication.translate("TabWidget", "Instruction", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_RunFLAT.setText(QtGui.QApplication.translate("TabWidget", "Run FLAT and Visualize/\n"
"Download Reulsts", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_3.setTitle(QtGui.QApplication.translate("TabWidget", "Log", None, QtGui.QApplication.UnicodeUTF8))
        TabWidget.setTabText(TabWidget.indexOf(self.tab1), QtGui.QApplication.translate("TabWidget", "Model Set-up", None, QtGui.QApplication.UnicodeUTF8))
        self.label_8.setText(QtGui.QApplication.translate("TabWidget", "Model Results", None, QtGui.QApplication.UnicodeUTF8))
        self.label_9.setText(QtGui.QApplication.translate("TabWidget", "Coefficient estimates and standard errors", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_DownloadMD.setText(QtGui.QApplication.translate("TabWidget", "Download", None, QtGui.QApplication.UnicodeUTF8))
        self.label_10.setText(QtGui.QApplication.translate("TabWidget", "Predicted Dependent Variable Fractions by Pixel", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_DownloadPD.setText(QtGui.QApplication.translate("TabWidget", "Download", None, QtGui.QApplication.UnicodeUTF8))
        self.label_11.setText(QtGui.QApplication.translate("TabWidget", "Covariance Matrix for Parameter Estiamtes", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_DownloadCM.setText(QtGui.QApplication.translate("TabWidget", "Download", None, QtGui.QApplication.UnicodeUTF8))
        self.label_12.setText(QtGui.QApplication.translate("TabWidget", "Instructions for Calculations of Marginal Effects and Odds Ratio", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_DownloadInstructions.setText(QtGui.QApplication.translate("TabWidget", "Download", None, QtGui.QApplication.UnicodeUTF8))
        TabWidget.setTabText(TabWidget.indexOf(self.tab2), QtGui.QApplication.translate("TabWidget", "Model Results", None, QtGui.QApplication.UnicodeUTF8))
        self.label_15.setText(QtGui.QApplication.translate("TabWidget", "Plot Area", None, QtGui.QApplication.UnicodeUTF8))
        self.label_14.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body><p>Select Region on the</p><p>Plot Area to Map*</p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.label_13.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body><p>Select Depedent </p><p>Variable to Map</p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.label_16.setText(QtGui.QApplication.translate("TabWidget", "<html><head/><body><p>*Move and resize the </p><p>drag and size box to </p><p>select region to map</p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_GenNewMap.setText(QtGui.QApplication.translate("TabWidget", "Generate New Map", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_SaveMap.setText(QtGui.QApplication.translate("TabWidget", "Save Map", None, QtGui.QApplication.UnicodeUTF8))
        TabWidget.setTabText(TabWidget.indexOf(self.tab3), QtGui.QApplication.translate("TabWidget", "Visualize Results", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    # create QT application
    app = QtGui.QApplication(sys.argv)
    # Initialize gabbs maps libraries
    gabbs.maps.gbsLoadLibrary()

    TabWidget = QtGui.QTabWidget()
    ui = Ui_TabWidget()
    ui.setupUi(TabWidget)
    TabWidget.show()


    sys.exit(app.exec_())
    # Exit gabbas maps libraries
    gabbs.maps.gbsUnloadLibrary()

