import os
import sys
import re
import subprocess

def process_upload(file_path):
    print 'upload to %s'%file_path
    importCommand = '/usr/bin/importfile'
    try:
        subprocess.Popen([importCommand, file_path]);
    except:
        print 'failed to upload'
    return

def process_download(file_path):
    print 'donwload %s'%file_path
    exportCommand = '/usr/bin/exportfile'
    try:
        subprocess.Popen([exportCommand, file_path])
    except:
        print 'failed to download'
    return

def replace_file(file_path, str_ori, str_dst):
    if not os.path.isfile(file_path):
        return
    with open(file_path,'r') as f:
        co = f.read()
    new_co = re.sub(str_ori, str_dst, co)
    with open(file_path,'w') as f:
        f.write(new_co)
    return


